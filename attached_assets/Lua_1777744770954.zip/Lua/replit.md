# Portfolio Hub - Jennipher Troup

## Overview
A portfolio website showcasing AI + UX systems design work. Built with React + Vite, featuring interactive prototypes and written work.

## Architecture
- **Framework**: React 19 + Vite 7
- **Routing**: react-router-dom with HashRouter
- **Styling**: Inline styles + CSS utility classes with consistent dark theme
- **Responsive**: Mobile-first with CSS media queries (768px, 480px breakpoints)
- **Interactions**: CSS utility classes (click-scale, glow-hover, card-interactive, nav-scroll) for sub-100ms feedback
- **Port**: 5000 (Vite dev server)

## Pages
1. **Home** (`/`) - Landing page with project cards
2. **Architecture Visualizer** (`/architecture`) - Interactive e-commerce system diagram with priority filtering and component deep-dives
3. **Deep Dive** (`/deep-dive`) - Database schema explorer, checkout flow walkthrough, scaling roadmap, security checklist
4. **AI Workflow** (`/ai-workflow`) - Narrative-governed AI workflow prototype with input classification, behavioral sliders, and output quality dashboard
5. **Thinking Partner** (`/thinking-partner`) - Cognitive architecture demo with 4 reasoning layers (Context/Analysis/Challenge/Synthesis), animated text, confidence rings, Web Audio API sound effects, Socratic follow-up questions, and input classification (team/career/product/default scenarios)
6. **Writing** (`/writing`) - "The Useful Villains Nobody Thanks" essay

## Project Structure
```
src/
  main.jsx          - Entry point
  App.jsx           - Router configuration
  index.css         - Global styles
  components/
    Layout.jsx      - Nav bar + layout wrapper
  pages/
    Home.jsx        - Landing page
    ArchitectureVisualizer.jsx - Interactive architecture diagram
    DeepDive.jsx    - Technical reference (schema, checkout, scaling, security)
    AIWorkflow.jsx  - AI workflow prototype
    ThinkingPartner.jsx - Cognitive architecture + Socratic inquiry demo
    Writing.jsx     - Essay page
```

## Running
```
npm run dev
```
