import { useState } from "react";

const layers = [
  {
    id: "client",
    label: "Client Layer",
    color: "#f0fdf4",
    border: "#86efac",
    accent: "#16a34a",
    nodes: [
      {
        id: "nextjs",
        title: "Next.js (App Router)",
        role: "Frontend Framework",
        why: "Full-stack React with SSR/SSG baked in — great for SEO-critical product pages. Handles storefront, checkout, and admin in one repo, which matters a lot for a solo team.",
        tradeoffs: "Tight coupling of front/back by default. Fine for now; split later if needed.",
        links: ["vercel"],
        tags: ["Fast TTM", "Scalable"],
      },
      {
        id: "tailwind",
        title: "Tailwind CSS + shadcn/ui",
        role: "UI Styling",
        why: "Design-system-in-a-box. Zero context-switching, no custom CSS files to maintain. Extremely fast to build polished UIs solo.",
        tradeoffs: "HTML can get verbose. Use component abstraction to stay sane.",
        links: [],
        tags: ["Fast TTM", "Cost"],
      },
    ],
  },
  {
    id: "edge",
    label: "Edge & Delivery",
    color: "#eff6ff",
    border: "#93c5fd",
    accent: "#2563eb",
    nodes: [
      {
        id: "vercel",
        title: "Vercel",
        role: "Hosting + Edge Network",
        why: "Zero-config deploys from Git. Global CDN, edge functions, automatic preview URLs per PR. Scales to zero so you don't pay when traffic is low.",
        tradeoffs: "Can get expensive at high traffic. Migrate to self-hosted infra if you hit $500+/mo.",
        links: ["nextjs", "cloudflare"],
        tags: ["Fast TTM", "Scalable", "Cost"],
      },
      {
        id: "cloudflare",
        title: "Cloudflare",
        role: "CDN + DDoS + WAF",
        why: "Free tier covers most needs: DDoS protection, WAF rules, asset caching. Critical for a commerce site that's a fraud/bot target.",
        tradeoffs: "Adds a DNS hop. Minor latency in rare configs.",
        links: ["vercel"],
        tags: ["Security", "Cost"],
      },
    ],
  },
  {
    id: "api",
    label: "API & Business Logic",
    color: "#fdf4ff",
    border: "#d8b4fe",
    accent: "#7c3aed",
    nodes: [
      {
        id: "nextapi",
        title: "Next.js API Routes / tRPC",
        role: "Backend API",
        why: "Keep it in the same repo for now. tRPC gives you end-to-end type safety (TypeScript client ↔ server) with zero code gen. Massive DX win for a small team.",
        tradeoffs: "Harder to expose as a public API later. Plan your route structure early.",
        links: ["postgres", "stripe", "auth"],
        tags: ["Fast TTM", "Scalable"],
      },
      {
        id: "auth",
        title: "Auth.js (NextAuth) or Clerk",
        role: "Authentication & Sessions",
        why: "Auth.js is free/open-source with OAuth, magic links, JWT. Clerk is a paid SaaS that handles it all (MFA, org management) — worth it to skip building auth entirely.",
        tradeoffs: "Clerk adds ~$25-100/mo cost. Auth.js requires more setup but is free forever.",
        links: ["nextapi"],
        tags: ["Security", "Fast TTM"],
      },
    ],
  },
  {
    id: "data",
    label: "Data Layer",
    color: "#fff7ed",
    border: "#fdba74",
    accent: "#ea580c",
    nodes: [
      {
        id: "postgres",
        title: "PostgreSQL (via Neon or Supabase)",
        role: "Primary Database",
        why: "Relational DB for orders, users, products, inventory. Neon is serverless (scales to zero, branching for dev). Supabase adds real-time and a REST API layer for free.",
        tradeoffs: "Supabase adds opinions. Neon is simpler if you already have an ORM (Prisma/Drizzle).",
        links: ["nextapi", "redis"],
        tags: ["Cost", "Scalable"],
      },
      {
        id: "redis",
        title: "Redis (Upstash)",
        role: "Caching + Rate Limiting",
        why: "Cache product listings, session data, rate-limit API routes. Upstash is serverless Redis — pay per request, no idle cost. Essential for performance at scale.",
        tradeoffs: "Eventually consistent. Never store source-of-truth data here.",
        links: ["nextapi"],
        tags: ["Scalable", "Cost"],
      },
      {
        id: "s3",
        title: "Cloudflare R2 / S3",
        role: "Object Storage (Images, Files)",
        why: "Product images, receipts, uploads. Cloudflare R2 has no egress fees (unlike AWS S3) — major cost saver for image-heavy catalogs.",
        tradeoffs: "R2 ecosystem is younger than S3. AWS S3 is safer if you rely on advanced features.",
        links: [],
        tags: ["Cost"],
      },
    ],
  },
  {
    id: "commerce",
    label: "Commerce Services",
    color: "#fefce8",
    border: "#fde047",
    accent: "#ca8a04",
    nodes: [
      {
        id: "stripe",
        title: "Stripe",
        role: "Payments + Billing",
        why: "Industry standard. Handles checkout, subscriptions, tax calculation, fraud detection, payouts. PCI-compliant out of the box so you don't have to be.",
        tradeoffs: "2.9% + 30¢ per transaction. Look at Lemon Squeezy or Paddle for SaaS/digital goods (they handle VAT/tax).",
        links: ["nextapi"],
        tags: ["Security", "Fast TTM"],
      },
      {
        id: "search",
        title: "Algolia or Typesense",
        role: "Product Search",
        why: "Faceted search, typo-tolerance, instant results. Algolia is plug-and-play. Typesense is open-source and self-hostable (cheaper at scale).",
        tradeoffs: "Algolia free tier is generous early on. Switch to Typesense on Railway/Fly.io if costs climb.",
        links: ["nextapi"],
        tags: ["Scalable", "Fast TTM"],
      },
      {
        id: "email",
        title: "Resend + React Email",
        role: "Transactional Email",
        why: "Order confirmations, shipping updates, receipts. React Email lets you build emails like React components. Resend has a generous free tier and great deliverability.",
        tradeoffs: "For marketing email (newsletters), add Loops.so or Mailchimp separately.",
        links: ["nextapi"],
        tags: ["Fast TTM", "Cost"],
      },
    ],
  },
  {
    id: "ops",
    label: "Observability & DevOps",
    color: "#f0f9ff",
    border: "#7dd3fc",
    accent: "#0284c7",
    nodes: [
      {
        id: "monitoring",
        title: "Sentry + Vercel Analytics",
        role: "Error Tracking + Analytics",
        why: "Sentry catches errors in real-time with stack traces. Vercel Analytics gives you real-user performance data (Core Web Vitals). Both have free tiers.",
        tradeoffs: "Add PostHog for product analytics (funnels, session replay) if you need deeper insights.",
        links: [],
        tags: ["Scalable"],
      },
      {
        id: "ci",
        title: "GitHub Actions",
        role: "CI/CD",
        why: "Lint, typecheck, test on every PR. Free for public repos, generous minutes for private. Vercel auto-deploys on merge — so this is mostly about guards, not deployment.",
        tradeoffs: "Consider adding Playwright E2E tests for checkout flows early — they're hard to retrofit.",
        links: [],
        tags: ["Fast TTM", "Security"],
      },
    ],
  },
];

const tagColors = {
  "Fast TTM": { bg: "#dcfce7", text: "#166534" },
  Scalable: { bg: "#dbeafe", text: "#1e40af" },
  Cost: { bg: "#fef9c3", text: "#854d0e" },
  Security: { bg: "#fce7f3", text: "#9d174d" },
};

export default function App() {
  const [selected, setSelected] = useState(null);
  const [hoveredTag, setHoveredTag] = useState(null);

  const allNodes = layers.flatMap((l) => l.nodes);
  const selectedNode = allNodes.find((n) => n.id === selected);

  const isHighlighted = (node) => {
    if (!hoveredTag) return true;
    return node.tags.includes(hoveredTag);
  };

  return (
    <div style={{
      fontFamily: "'DM Mono', 'Fira Code', 'Courier New', monospace",
      background: "#0f0f11",
      minHeight: "100vh",
      padding: "32px 24px",
      color: "#e2e8f0",
    }}>
      {/* Header */}
      <div style={{ marginBottom: 32, maxWidth: 900, margin: "0 auto 32px" }}>
        <div style={{ display: "flex", alignItems: "baseline", gap: 12, marginBottom: 8 }}>
          <span style={{ fontSize: 11, color: "#6b7280", letterSpacing: 3, textTransform: "uppercase" }}>Architecture Blueprint</span>
          <span style={{ fontSize: 11, color: "#374151", letterSpacing: 1 }}>v1.0</span>
        </div>
        <h1 style={{ fontSize: 26, fontWeight: 700, color: "#f9fafb", margin: "0 0 4px", letterSpacing: -0.5 }}>
          E-Commerce / Marketplace
        </h1>
        <p style={{ fontSize: 13, color: "#9ca3af", margin: 0 }}>
          Solo team · Fast time to market · Scalable · Cost-efficient · Secure
        </p>
      </div>

      {/* Priority filter pills */}
      <div style={{ maxWidth: 900, margin: "0 auto 24px", display: "flex", gap: 8, flexWrap: "wrap" }}>
        <span style={{ fontSize: 11, color: "#6b7280", alignSelf: "center", marginRight: 4 }}>FILTER BY PRIORITY →</span>
        {Object.entries(tagColors).map(([tag, colors]) => (
          <button
            key={tag}
            onClick={() => setHoveredTag(hoveredTag === tag ? null : tag)}
            style={{
              padding: "4px 12px",
              borderRadius: 20,
              border: `1px solid ${hoveredTag === tag ? colors.text : "#374151"}`,
              background: hoveredTag === tag ? colors.bg : "transparent",
              color: hoveredTag === tag ? colors.text : "#9ca3af",
              fontSize: 11,
              cursor: "pointer",
              fontFamily: "inherit",
              fontWeight: 600,
              letterSpacing: 0.5,
              transition: "all 0.15s",
            }}
          >
            {tag === "Fast TTM" ? "⚡ Fast TTM" : tag === "Scalable" ? "📈 Scalable" : tag === "Cost" ? "💰 Cost" : "🔒 Security"}
          </button>
        ))}
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", display: "flex", gap: 20, alignItems: "flex-start" }}>
        {/* Main diagram */}
        <div style={{ flex: 1 }}>
          {layers.map((layer) => (
            <div key={layer.id} style={{ marginBottom: 12 }}>
              <div style={{
                fontSize: 10,
                color: layer.accent,
                letterSpacing: 3,
                textTransform: "uppercase",
                marginBottom: 6,
                paddingLeft: 4,
              }}>
                {layer.label}
              </div>
              <div style={{
                display: "grid",
                gridTemplateColumns: `repeat(${layer.nodes.length}, 1fr)`,
                gap: 8,
              }}>
                {layer.nodes.map((node) => {
                  const highlighted = isHighlighted(node);
                  const isSelected = selected === node.id;
                  return (
                    <button
                      key={node.id}
                      onClick={() => setSelected(isSelected ? null : node.id)}
                      style={{
                        background: isSelected ? layer.color : highlighted ? "#1a1a1f" : "#111114",
                        border: `1px solid ${isSelected ? layer.border : highlighted ? "#2d2d35" : "#1f1f24"}`,
                        borderRadius: 8,
                        padding: "14px 16px",
                        textAlign: "left",
                        cursor: "pointer",
                        transition: "all 0.15s ease",
                        opacity: highlighted ? 1 : 0.3,
                        boxShadow: isSelected ? `0 0 0 2px ${layer.accent}40, 0 4px 20px ${layer.accent}20` : "none",
                      }}
                    >
                      <div style={{
                        fontSize: 13,
                        fontWeight: 700,
                        color: isSelected ? layer.accent : highlighted ? "#e2e8f0" : "#6b7280",
                        marginBottom: 3,
                        letterSpacing: -0.3,
                      }}>
                        {node.title}
                      </div>
                      <div style={{
                        fontSize: 10,
                        color: isSelected ? "#6b7280" : "#4b5563",
                        letterSpacing: 0.5,
                        marginBottom: 8,
                      }}>
                        {node.role}
                      </div>
                      <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                        {node.tags.map((tag) => (
                          <span key={tag} style={{
                            fontSize: 9,
                            padding: "2px 6px",
                            borderRadius: 10,
                            background: isSelected || highlighted ? tagColors[tag].bg : "#1f1f24",
                            color: isSelected || highlighted ? tagColors[tag].text : "#4b5563",
                            fontWeight: 600,
                            letterSpacing: 0.3,
                          }}>
                            {tag}
                          </span>
                        ))}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Detail panel */}
        <div style={{
          width: 280,
          flexShrink: 0,
          position: "sticky",
          top: 24,
        }}>
          {selectedNode ? (() => {
            const layer = layers.find(l => l.nodes.some(n => n.id === selectedNode.id));
            return (
              <div style={{
                background: layer.color,
                border: `1px solid ${layer.border}`,
                borderRadius: 12,
                padding: 20,
                color: "#111",
              }}>
                <div style={{ fontSize: 10, color: layer.accent, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6, fontWeight: 700 }}>
                  {layer.label}
                </div>
                <div style={{ fontSize: 16, fontWeight: 800, color: "#111", marginBottom: 2, letterSpacing: -0.5 }}>
                  {selectedNode.title}
                </div>
                <div style={{ fontSize: 11, color: "#6b7280", marginBottom: 16, letterSpacing: 0.5 }}>
                  {selectedNode.role}
                </div>

                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: layer.accent, letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>
                    WHY THIS
                  </div>
                  <p style={{ fontSize: 12, color: "#374151", margin: 0, lineHeight: 1.7 }}>
                    {selectedNode.why}
                  </p>
                </div>

                <div style={{ marginBottom: 14 }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: "#9ca3af", letterSpacing: 2, textTransform: "uppercase", marginBottom: 6 }}>
                    TRADEOFFS
                  </div>
                  <p style={{ fontSize: 12, color: "#6b7280", margin: 0, lineHeight: 1.7 }}>
                    {selectedNode.tradeoffs}
                  </p>
                </div>

                <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                  {selectedNode.tags.map((tag) => (
                    <span key={tag} style={{
                      fontSize: 10,
                      padding: "3px 8px",
                      borderRadius: 10,
                      background: tagColors[tag].bg,
                      color: tagColors[tag].text,
                      fontWeight: 700,
                    }}>
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            );
          })() : (
            <div style={{
              background: "#1a1a1f",
              border: "1px solid #2d2d35",
              borderRadius: 12,
              padding: 20,
              textAlign: "center",
            }}>
              <div style={{ fontSize: 28, marginBottom: 12 }}>←</div>
              <div style={{ fontSize: 12, color: "#6b7280", lineHeight: 1.7 }}>
                Click any component to see why it was chosen, tradeoffs, and how it fits your priorities.
              </div>
              <div style={{ marginTop: 20, paddingTop: 16, borderTop: "1px solid #2d2d35" }}>
                <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 1, textTransform: "uppercase", marginBottom: 10 }}>Stack summary</div>
                {[
                  ["Frontend", "Next.js + Tailwind"],
                  ["Hosting", "Vercel + Cloudflare"],
                  ["Database", "PostgreSQL (Neon)"],
                  ["Payments", "Stripe"],
                  ["Auth", "Auth.js / Clerk"],
                  ["Search", "Algolia / Typesense"],
                  ["Email", "Resend"],
                  ["Cache", "Upstash Redis"],
                  ["Storage", "Cloudflare R2"],
                ].map(([label, val]) => (
                  <div key={label} style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 11 }}>
                    <span style={{ color: "#6b7280" }}>{label}</span>
                    <span style={{ color: "#d1d5db", fontWeight: 600 }}>{val}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: "20px auto 0", fontSize: 11, color: "#374151", textAlign: "center" }}>
        Click any component to explore it · Use filter pills to highlight by priority
      </div>
    </div>
  );
}
