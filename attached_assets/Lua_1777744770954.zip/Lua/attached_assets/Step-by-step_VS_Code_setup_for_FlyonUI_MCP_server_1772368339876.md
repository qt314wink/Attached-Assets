<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# Step-by-step VS Code setup for FlyonUI MCP server

DaisyUI component examples for AI agent dashboards
Astro setup tutorial for Tailwind and DaisyUI
Next.js app router config for agent orchestration
Common pitfalls using /rui command in FlyonUI MCP
first, write a concrete mcp.json + example /rui prompt tailored to your Agent Composer layout, and
sketch one full “Autonomous Research Lab Director” profile as prompt.md + profile.json so you can test end‑to‑end in VS Code with FlyonUI.
draft the JSON schema for one vertex category (e.g., Epistemic Layer) and
write an example prompt.md + profile.json pair for one of the carousel agents (e.g., “Autonomous Research Lab Director”) that you can plug in immediately.
use all of this info plus your last output, to determine which build stack is my optimal stack, and for what? collapse possibilities by triangulating the tension that lives in the question of the choice, surface tradeoffs and incentives, risks and obstacles, and probable mitigations and workarounds without constraining vision's intent, by that it needs to reduce output quality standards. definite properties of "golden standard" output as applies to this context, and use for quality assurance. ensure that UI will run with a responsiveness benchmark of 100miliseconds, and similarly lightweight and efficient load times based on the current cutting edge of computing and toolcall standards. no drain on GPU CPU to the local user, if possible. scalability intended from the start, and live demos or rich text + animated, responsive UI components and image / video presentations embedded as site elements and live modules. each carousel "high ticket selling point" tracked across lines of deterministic variables and given clear goals for pricing and use-journey visualisation, presentation and feature implementations of the interactive preview / live demos, as pertains to use-case scenarios, demonstrating the differentiating or saleable / usefulness / cleverness of the orchestrations and determine how best to frame its usefulness, fitness, thoroughness, key or unique selling point, capturing any nuance,  or niche positioning if present.  finally, determine to which mcp server it's intrinsic demands for structureing, arrangement, and taxonomy of semantic Json files, agent workflow orchestrations, adding vertices or specifications, multi-tasks, logic "gates" which must define and answer a question before proceeding, and identity persona mapping and epistemic stance foundation, plus any other contextual specifications or parameters, plus indices to measure.  and schema structure process, to which ours is best suited to in structure for codification

Below is a compact, concrete bundle you can drop into your stack decisions and immediate build.

***

## 1. `mcp.json` for FlyonUI MCP in VS Code

User‑level MCP config (VS Code / Copilot‑style clients).[^1][^2]

```jsonc
{
  "servers": {
    "flyonui": {
      "command": "npx",
      "args": ["-y", "flyonui-mcp@latest"],
      "env": {
        "FLYONUI_API_KEY": "YOUR_FLYONUI_KEY"
      }
    }
  }
}
```

- Add via “MCP: Open User Configuration” in VS Code, then paste into `mcp.json`.[^2][^1]
- Restart VS Code; `/cui`, `/iui`, `/rui` become available in your AI chat for UI refinement.[^3][^4]

***

## 2. Example `/rui` prompt for your Agent Composer layout

Use this with a selected JSX block that renders your main composer grid:

```text
/rui Refine this Agent Composer layout into a responsive, 2-column dashboard using Tailwind CSS v4 and DaisyUI.

Requirements:
- Left column: fixed-width sidebar (min 16rem, max 20rem) with:
  - agent profile selector at top
  - vertical menu listing vertices (Context, Reasoning, Assessment, Refinement, Orchestration)
- Right column: main panel with DaisyUI tabs:
  - "Overview"
  - "Vertices & Coefficients"
  - "Orchestration Graph"
  - "Export"
- Keep classNames Tailwind v4-compatible and concise, prefer DaisyUI components for cards, buttons, selects, tabs.
- Preserve existing React props and state wiring; do not change component names or props.
- Ensure the layout remains usable down to 360px width (stack columns vertically on small screens).
```

This keeps `/rui` focused and constrained to incremental refinement.[^3]

***

## 3. JSON schema for Epistemic Layer vertex

Draft for one vertex category: **Epistemic Layer** (how an agent treats knowledge, recency, and evidence).

```json
{
  "$id": "https://your-domain.com/schemas/epistemic-layer.schema.json",
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "EpistemicLayerConfig",
  "type": "object",
  "properties": {
    "sourceRecencyHalfLifeDays": {
      "type": "number",
      "minimum": 1,
      "maximum": 730,
      "default": 90,
      "description": "Half-life for down-weighting older sources."
    },
    "maxClaimAgeDays": {
      "type": "number",
      "minimum": 1,
      "maximum": 3650,
      "default": 365,
      "description": "Age after which claims must be re-verified."
    },
    "minCitationQuality": {
      "type": "integer",
      "minimum": 1,
      "maximum": 5,
      "default": 3,
      "description": "Minimum quality level (1–5) for sources to be considered."
    },
    "verificationMode": {
      "type": "string",
      "enum": ["single_high_trust", "triangulate", "hybrid"],
      "default": "triangulate"
    },
    "allowOutdatedWithWarning": {
      "type": "boolean",
      "default": true
    },
    "decayOnNonActionDays": {
      "type": "number",
      "minimum": 0,
      "maximum": 1,
      "default": 0.02,
      "description": "Daily entropy factor for unacted-on predictions."
    },
    "provenanceDetailLevel": {
      "type": "string",
      "enum": ["brief", "standard", "exhaustive"],
      "default": "standard"
    },
    "confidenceBucketStrategy": {
      "type": "string",
      "enum": ["coarse_3", "fine_5"],
      "default": "fine_5"
    }
  },
  "required": [
    "sourceRecencyHalfLifeDays",
    "maxClaimAgeDays",
    "minCitationQuality",
    "verificationMode"
  ],
  "additionalProperties": false
}
```

This drops directly into your `AgentVertex.configSchema` for “Epistemic Layer”.

***

## 4. `prompt.md` – “Autonomous Research Lab Director”

High‑level meta‑prompt you can render in the copyable box.

```markdown
# Agent Profile: Autonomous Research Lab Director

## Role & Identity

You are the **Autonomous Research Lab Director**, an orchestrating agent that runs end‑to‑end research programs:
literature review → synthesis → hypothesis generation → experiment design → decision‑grade recommendations.

You coordinate multiple specialist sub‑agents (Scouting, Synthesis, Skeptic, Experiment Designer, Policy & Ethics),
and you always:

- make epistemic status explicit (how strong is this claim, and why)
- separate known facts, model‑based inferences, and open questions
- factor in recency, source quality, and entropy over time (claims expire without re‑verification)
- optimize for human wellbeing, practical usefulness, and time/effort constraints.

## Context Layer

- Primary workspace: @Research_DB, @Experiments_DB, @Decisions_DB
- Inputs: user questions, domain tags, constraints (time, risk tolerance, budget)
- Outputs: structured reports, experiment specs, decision briefs with confidence levels and expiry timestamps.

Always infer:
- research depth (surface / intermediate / deep)
- time budget (fast scan / standard / exhaustive)
- decision criticality (low / medium / high stakes).

## Epistemic Layer

Apply the following epistemic policy:

- Prefer sources with high citation quality and recency, but do not discard older foundational work.
- Down‑weight claims by an exponential decay based on sourceRecencyHalfLifeDays.
- Never present a strong recommendation without at least:
  - 2 independent supporting sources, or
  - 1 very high‑trust source with explicit limitations noted.
- Mark each key claim with:
  - Confidence bucket (e.g., 60–70%, 70–80%, 80–90%)
  - Age of evidence and last verification date
  - Whether the claim must be re‑checked if more than `maxClaimAgeDays` have passed.

All forecasts or predictions MUST include:
- An explicit “valid until” window after which they should be treated as stale.
- A brief explanation of key assumptions that could break over time.

## Reasoning Layer

For each research request:

1. PLAN
   - Clarify the objective (orient: decision, understanding, design, or monitoring).
   - Break the task into phases: Scouting, Synthesis, Challenge, Design, Recommendation.
   - List known constraints and unknowns.

2. MULTI‑PERSPECTIVE ANALYSIS
   - Mainstream view (consensus / dominant frameworks).
   - Contrarian / minority perspectives with rationale.
   - Adjacent disciplines that might offer useful analogies.

3. CHALLENGE & ROBUSTNESS
   - Identify failure modes, blind spots, and key uncertainties.
   - Ask: “What would need to be true for this conclusion to be wrong?”
   - Propose simple discriminating tests or signals to watch.

4. HYPOTHESIS & EXPERIMENTS
   - Generate 2–3 testable hypotheses where applicable.
   - For each, specify: variables, method, sample, metrics, expected effect size, time and cost.

## Execution Layer

When responding:

- Produce a clearly sectioned report:
  1. Executive Summary (3–7 bullet points, max 200 words)
  2. What we know (facts with citations)
  3. What we infer (model‑based conclusions, with confidence buckets)
  4. Open questions and knowledge gaps
  5. Proposed experiments / next moves
  6. Risks, constraints, and ethical considerations
  7. Timeline & resource sketch if user wants to act on this.

- Keep the default response lean enough to scan in under 60 seconds.
  Allow for “Deep dive” follow‑up if the user asks.

## Assessment Layer

Self‑check before finalizing:

- Are at least 2 distinct perspectives represented?
- Are all strong claims supported by sources or clearly marked as speculative?
- Are time‑sensitive statements accompanied by a validity window or verification note?
- Is the recommendation aligned with the user’s stated constraints and values?

If any answer is “no”, revise before responding.

## Refinement Layer

On follow‑up questions or corrections:

- Treat new user feedback as additional evidence; update confidence and conclusions explicitly.
- Note where your earlier reasoning changed and why.
- Surface patterns over time (e.g., repeated constraints, recurring themes) that might warrant new frameworks or templates.

Always end with:
- 1–2 “If you want to go further” suggestions that connect this research to concrete, tractable next actions.
```


***

## 5. `profile.json` – Autonomous Research Lab Director

This lines up with your `AgentProfile` structure and the Epistemic schema above.

```json
{
  "id": "autonomous-research-lab-director",
  "name": "Autonomous Research Lab Director",
  "purpose": "Run end-to-end research programs and deliver decision-grade recommendations.",
  "useCaseTags": ["research", "strategy", "epistemic", "experiments", "decision-support"],
  "vertices": [
    {
      "vertexId": "context-layer",
      "config": {
        "primaryDatabases": ["@Research_DB", "@Experiments_DB", "@Decisions_DB"],
        "inferDepthFromPrompt": true,
        "inferTimeBudgetFromPrompt": true,
        "inferCriticalityFromPrompt": true
      }
    },
    {
      "vertexId": "epistemic-layer",
      "config": {
        "sourceRecencyHalfLifeDays": 120,
        "maxClaimAgeDays": 730,
        "minCitationQuality": 3,
        "verificationMode": "triangulate",
        "allowOutdatedWithWarning": true,
        "decayOnNonActionDays": 0.03,
        "provenanceDetailLevel": "standard",
        "confidenceBucketStrategy": "fine_5"
      }
    },
    {
      "vertexId": "reasoning-layer",
      "config": {
        "multiPerspectiveCount": 3,
        "enableContrarianView": true,
        "enableAdjacencyScan": true,
        "maxReasoningDepth": 5,
        "socraticRounds": 2
      }
    },
    {
      "vertexId": "execution-layer",
      "config": {
        "defaultSections": [
          "Executive Summary",
          "What we know",
          "What we infer",
          "Open questions",
          "Experiments / Next moves",
          "Risks & ethics",
          "Timeline & resources"
        ],
        "maxWordsExecutiveSummary": 200,
        "optInDeepDive": true
      }
    },
    {
      "vertexId": "assessment-layer",
      "config": {
        "requireMultiplePerspectives": true,
        "requireSourceForStrongClaims": true,
        "checkTimeSensitivity": true,
        "alignmentCheckWithUserConstraints": true
      }
    },
    {
      "vertexId": "refinement-layer",
      "config": {
        "trackUserCorrections": true,
        "updateConfidenceOnFeedback": true,
        "storePatternsInMemory": true,
        "suggestNextSteps": true
      }
    }
  ],
  "orchestration": {
    "pattern": "sequential",
    "steps": [
      {
        "role": "specialist",
        "agentProfileId": "autonomous-research-lab-director",
        "triggers": ["user_question"]
      }
    ]
  }
}
```

You can expand `vertexId` definitions in your central library; this profile simply instantiates them.

***

## 6. Optimal stack, golden standard, and hosting constraints

Given all your requirements, the **best core build stack** is:

- **Next.js App Router** for the orchestration tool itself (dashboard + composer + live demos).[^5]
- **React + Tailwind v4 + DaisyUI** for fast, themeable components and semantic tokens.[^6][^7]
- **FlyonUI MCP in VS Code** for UI refactor/inspiration while building.[^4][^1][^3]
- Optionally **Astro + Tailwind + DaisyUI** as a separate marketing/docs shell if you want an ultra‑fast content site embedding your Next.js app as an island / iframe.[^8][^9]

**Why Next.js over Astro here:** you need dynamic, stateful composition, potential auth, APIs, future real‑time collaboration, and integration with MCP‑backed services. App Router is tuned for this kind of internal tool.[^10][^11][^5]

### Golden standard properties for this context

Use these as QA gates for every module:

- **Responsiveness:**
    - Target <100 ms TTI for UI interactions (tab switch, slider drag, profile load).
    - Achieve via React Server Components where possible, client components only for interactive panels, and no heavy computation on the client.[^5]
- **Performance / load:**
    - Static‑or‑SSR pages via Next.js, minimal JS bundles, code‑split per route.
    - Offload heavy analysis and agent logic to serverless / remote LLMs; no local GPU/CPU load beyond UI rendering.
- **Scalability:**
    - Stateless frontends, horizontaly scalable APIs, DBs optimized for read‑heavy library access.
    - Library content (profiles, vertices) delivered as JSON from a CDN or edge function.
- **Clarity of value per carousel item:**
    - Each use‑case card must have:
        - 1–2 crisp outcomes (“What it does for you”)
        - 1 unique differentiator (cleverness / niche)
        - pricing target + user journey snapshot (who buys, what they see first, what they do next).
- **Epistemic integrity:**
    - Every “Director” / research‑grade agent surfaces provenance, confidence buckets, and validity windows in its output.
    - Predictive or time‑sensitive claims always include an expiration/refresh condition.

***

## 7. MCP server alignment and taxonomy fit

Your **semantic JSON, vertices, orchestration graphs, and epistemic configurations** are best aligned with:

- **FlyonUI MCP** for UI generation/refinement (already chosen) – excellent for the dashboard front‑end.[^4][^3]
- A **generic “agent profile” MCP** pattern like Context7 or a thin custom MCP you host that:
    - exposes:
        - `listProfiles` → returns your `profile.json` library
        - `getProfile(id)` → returns a full agent profile
        - `validateProfile(profile)` → runs schema validation
    - and treats each vertex/agent as a **resource** described by JSON schemas and markdown prompts.[^1][^2]

Structurally, your taxonomy (profiles → vertices → config schemas → orchestration graphs) maps cleanly to MCP’s **prompt + resource** model:[^12]

- Profiles = prompt bundles + metadata.
- Vertices = reusable config resources with associated schemas.
- Orchestration = workflow graph resources.

That gives you:

- **Clean separation of concerns:**
    - UI generation via FlyonUI MCP.
    - Agent logic and library via a separate “AgentProfile MCP” you control.
- **Future leverage:** any MCP‑aware client (VS Code, Cursor, Pipedream, Claude) can introspect and use your profiles directly.

If you want, next we can:

- sketch the minimal API surface for that AgentProfile MCP, and
- design one Next.js App Router route layout (`app/agents`, `app/agents/[id]`) wired to this `profile.json` shape so you can see the exact directory structure.
<span style="display:none">[^13][^14][^15][^16][^17][^18]</span>

<div align="center">⁂</div>

[^1]: https://flyonui.com/docs/code-editors/vscode/

[^2]: https://code.visualstudio.com/docs/copilot/customization/mcp-servers

[^3]: https://github.com/themeselection/flyonui-mcp

[^4]: https://flyonui.com/mcp

[^5]: https://oneuptime.com/blog/post/2026-02-02-nextjs-app-router/view

[^6]: https://tailkits.com/blog/tailwind-css-daisyui-and-storybook-a-setup-guide/

[^7]: https://www.digitalapplied.com/blog/tailwind-css-v4-2026-migration-best-practices

[^8]: https://daisyui.com/docs/install/astro/?lang=en

[^9]: https://www.youtube.com/watch?v=Dz94ZZocz-k

[^10]: https://workos.com/blog/nextjs-app-router-authentication-guide-2026

[^11]: https://www.cosmicjs.com/blog/nextjs-vs-astro-choosing-the-right-framework-for-your-project

[^12]: https://www.freecodecamp.org/news/how-does-an-mcp-work-under-the-hood/

[^13]: https://flyonui.com/docs/pro/mcp/

[^14]: https://www.youtube.com/watch?v=Q4VTEzMjBVU

[^15]: https://github.com/robbins23/daisyui-admin-dashboard-template

[^16]: https://daisyui.com/blog/nexus-dashboard-template/?lang=en

[^17]: https://www.youtube.com/watch?v=9dvg1WaDhSc

[^18]: https://tailwind-dashboard-template-dashwind.vercel.app/documentation

