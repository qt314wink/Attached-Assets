<img src="https://r2cdn.perplexity.ai/pplx-full-logo-primary-dark%402x.png" style="height:64px;margin-right:32px"/>

# next step can be a tiny AgentComposer client component stub that:

renders the sidebar + tabs,
uses the promptMd and profile from profile.json, and
is structured so /cui and /rui can safely refactor it without breaking types.

Here's a tiny, self-contained `AgentComposer` client component that renders sidebar + tabs, consumes `promptMd` + `profile.json`, and is structured for `/cui` / `/rui` safe refactoring.

## `AgentComposer.tsx`

```tsx
"use client";

import { useState } from "react";
import { CopyButton } from "@/components/CopyButton"; // assume you have this
import type { AgentProfile } from "@/types/agent"; // your types

interface AgentComposerProps {
  initialPrompt: string;
  initialProfile: AgentProfile;
}

export default function AgentComposer({
  initialPrompt,
  initialProfile,
}: AgentComposerProps) {
  const [activeTab, setActiveTab] = useState("overview");
  const [profile, setProfile] = useState(initialProfile);

  const tabs = [
    { id: "overview", label: "Overview" },
    { id: "vertices", label: "Vertices & Coefficients" },
    { id: "orchestration", label: "Orchestration Graph" },
    { id: "export", label: "Export" },
  ];

  const vertices = profile.vertices || [];

  return (
    <div className="grid grid-cols-[minmax(16rem,20rem)_1fr] gap-6 h-full">
      {/* Sidebar */}
      <aside className="border-r border-border flex flex-col">
        {/* Profile header */}
        <div className="p-4 border-b border-border">
          <h2 className="text-lg font-semibold mb-1">{profile.name}</h2>
          <p className="text-sm text-zinc-600 mb-2">{profile.purpose}</p>
          <select className="select select-bordered select-sm w-full">
            <option>Load another profile...</option>
          </select>
        </div>

        {/* Vertices menu */}
        <div className="flex-1 overflow-y-auto p-4">
          <h3 className="text-sm font-medium mb-3 text-zinc-900">Vertices</h3>
          <ul className="menu menu-sm bg-base-100 rounded-box p-2 space-y-1">
            {vertices.map((v) => (
              <li key={v.vertexId}>
                <button className="text-left justify-start">
                  {v.vertexId}
                  <span className="ml-auto badge badge-xs badge-outline badge-primary">
                    edit
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex flex-col overflow-hidden">
        {/* Tabs */}
        <div role="tablist" className="tabs tabs-bordered tabs-lg border-b border-border">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              role="tab"
              className={`tab ${activeTab === tab.id ? "tab-active" : ""}`}
              onClick={() => setActiveTab(tab.id)}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab panels */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === "overview" && (
            <div className="space-y-4">
              <h1 className="text-2xl font-bold">{profile.name}</h1>
              <p className="text-lg text-zinc-700 max-w-2xl">{profile.purpose}</p>
              <div className="flex flex-wrap gap-2">
                {profile.useCaseTags?.map((tag) => (
                  <span key={tag} className="badge badge-lg badge-outline badge-secondary">
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}

          {activeTab === "vertices" && (
            <div className="grid gap-4">
              {vertices.map((v) => (
                <div key={v.vertexId} className="card bg-base-100 shadow-sm">
                  <div className="card-body">
                    <h3 className="card-title text-base">{v.vertexId}</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="label">
                          <span className="label-text">Recency Half‑Life (days)</span>
                        </label>
                        <input
                          type="range"
                          min="7"
                          max="730"
                          defaultValue="90"
                          className="range range-primary"
                        />
                      </div>
                      <div>
                        <label className="label">
                          <span className="label-text">Citation Quality</span>
                        </label>
                        <select className="select select-bordered w-full">
                          <option>3</option>
                          <option>4</option>
                          <option>5</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === "orchestration" && (
            <div className="flex items-center justify-center h-64 bg-base-200 rounded-lg">
              <p className="text-zinc-500">Orchestration graph preview (Mermaid / React Flow)</p>
            </div>
          )}

          {activeTab === "export" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Prompt */}
              <div className="flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold">Meta‑prompt</h3>
                  <CopyButton text={initialPrompt} />
                </div>
                <textarea
                  className="textarea textarea-bordered flex-1 font-mono text-xs resize-none"
                  readOnly
                  value={initialPrompt}
                />
              </div>

              {/* JSON */}
              <div className="flex flex-col">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-sm font-semibold">Profile JSON</h3>
                  <CopyButton text={JSON.stringify(profile, null, 2)} />
                </div>
                <pre className="textarea textarea-bordered flex-1 font-mono text-xs overflow-auto bg-base-100">
                  {JSON.stringify(profile, null, 2)}
                </pre>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
```


***

## Key design choices for `/cui` / `/rui` safety

1. **Semantic structure:** clear grid/split layout with labeled sections; easy to refactor without breaking semantics.
2. **DaisyUI primitives:** `card`, `tabs`, `menu`, `badge`, `range`, `select` – all FlyonUI knows well.
3. **Tailwind v4 canonical:** `grid-cols-[minmax(16rem,20rem)_1fr]`, `overflow-y-auto`, etc.
4. **Props preserved:** `initialPrompt`, `initialProfile` flow through unchanged.
5. **Type‑safe:** `AgentProfile` type keeps the JSON shape enforced.
6. **CopyButton:** assume a simple utility component:
```tsx
// components/CopyButton.tsx
'use client';
import { useState } from 'react';
import { copyToClipboard } from 'next/navigation'; // or your impl

export function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      className="btn btn-xs btn-outline"
      onClick={async () => {
        await copyToClipboard(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }}
    >
      {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}
```

This stub is:

- **fully functional** – copy/paste, switch tabs, see vertices.
- **refactor‑safe** – `/rui` can safely tweak layouts, add spacing, swap components.
- **extensible** – add real vertex editing, orchestration viz, etc.

Drop it into your Next.js app and it’s ready to iterate with FlyonUI MCP commands.

Want the `AgentProfile` types file next?

