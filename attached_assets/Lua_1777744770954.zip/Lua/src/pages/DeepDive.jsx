import { useState } from "react";

const TABS = [
  { id: "schema", label: "Database Schema" },
  { id: "checkout", label: "Checkout Flow" },
  { id: "scaling", label: "Scaling Roadmap" },
  { id: "security", label: "Security Checklist" },
];

const tables = [
  {
    name: "users",
    color: "#6366f1",
    desc: "Buyers and sellers. Role field distinguishes them.",
    columns: [
      { name: "id", type: "uuid", note: "Primary key, gen by default" },
      { name: "email", type: "text", note: "Unique, indexed" },
      { name: "name", type: "text", note: "" },
      { name: "role", type: "enum", note: "'buyer' | 'seller' | 'admin'" },
      { name: "stripe_customer_id", type: "text", note: "Nullable, set on first purchase" },
      { name: "created_at", type: "timestamptz", note: "Default now()" },
    ],
  },
  {
    name: "stores",
    color: "#0ea5e9",
    desc: "Seller storefronts. One seller can have one store.",
    columns: [
      { name: "id", type: "uuid", note: "Primary key" },
      { name: "owner_id", type: "uuid", note: "FK -> users.id" },
      { name: "name", type: "text", note: "Store display name" },
      { name: "slug", type: "text", note: "Unique URL slug" },
      { name: "stripe_account_id", type: "text", note: "Stripe Connect account for payouts" },
      { name: "created_at", type: "timestamptz", note: "" },
    ],
  },
  {
    name: "products",
    color: "#10b981",
    desc: "Items listed for sale. Soft-delete with deleted_at.",
    columns: [
      { name: "id", type: "uuid", note: "Primary key" },
      { name: "store_id", type: "uuid", note: "FK -> stores.id" },
      { name: "name", type: "text", note: "Indexed for search" },
      { name: "description", type: "text", note: "" },
      { name: "price_cents", type: "integer", note: "Always store money as cents!" },
      { name: "currency", type: "text", note: "Default 'usd'" },
      { name: "status", type: "enum", note: "'draft' | 'active' | 'archived'" },
      { name: "inventory_count", type: "integer", note: "Nullable = unlimited" },
      { name: "images", type: "text[]", note: "Array of R2/S3 URLs" },
      { name: "metadata", type: "jsonb", note: "Flexible attrs (color, size, etc.)" },
      { name: "deleted_at", type: "timestamptz", note: "Soft delete" },
      { name: "created_at", type: "timestamptz", note: "" },
    ],
  },
  {
    name: "orders",
    color: "#f59e0b",
    desc: "One order per checkout session. Status machine tracks lifecycle.",
    columns: [
      { name: "id", type: "uuid", note: "Primary key" },
      { name: "buyer_id", type: "uuid", note: "FK -> users.id" },
      { name: "status", type: "enum", note: "'pending' | 'paid' | 'fulfilled' | 'cancelled' | 'refunded'" },
      { name: "total_cents", type: "integer", note: "Sum of line items + shipping" },
      { name: "currency", type: "text", note: "" },
      { name: "stripe_payment_intent_id", type: "text", note: "Unique - idempotency key" },
      { name: "shipping_address", type: "jsonb", note: "Snapshot at time of order" },
      { name: "created_at", type: "timestamptz", note: "" },
      { name: "updated_at", type: "timestamptz", note: "" },
    ],
  },
  {
    name: "order_items",
    color: "#ec4899",
    desc: "Line items. Snapshot product details at purchase time - never join to live products for receipts.",
    columns: [
      { name: "id", type: "uuid", note: "" },
      { name: "order_id", type: "uuid", note: "FK -> orders.id" },
      { name: "product_id", type: "uuid", note: "FK -> products.id (reference only)" },
      { name: "store_id", type: "uuid", note: "FK -> stores.id" },
      { name: "quantity", type: "integer", note: "" },
      { name: "unit_price_cents", type: "integer", note: "Snapshotted at purchase" },
      { name: "product_name", type: "text", note: "Snapshotted at purchase" },
    ],
  },
  {
    name: "reviews",
    color: "#8b5cf6",
    desc: "Buyer reviews on products. One review per buyer per product.",
    columns: [
      { name: "id", type: "uuid", note: "" },
      { name: "product_id", type: "uuid", note: "FK -> products.id" },
      { name: "buyer_id", type: "uuid", note: "FK -> users.id" },
      { name: "rating", type: "integer", note: "1-5, check constraint" },
      { name: "body", type: "text", note: "Nullable" },
      { name: "created_at", type: "timestamptz", note: "" },
    ],
  },
];

const checkoutSteps = [
  {
    id: 1, phase: "Storefront", color: "#6366f1",
    title: "Product Page -> Add to Cart", actor: "Browser",
    description: "User browses and adds items. Cart state lives in localStorage (or a lightweight Zustand store). No server call needed yet - keeps it fast.",
    code: `// cart-store.ts (Zustand)
const useCart = create(persist((set) => ({
  items: [],
  add: (product) => set((s) => ({
    items: [...s.items, { ...product, qty: 1 }]
  })),
  clear: () => set({ items: [] }),
}), { name: 'cart' }))`,
    warnings: [],
  },
  {
    id: 2, phase: "Pre-checkout", color: "#0ea5e9",
    title: "Auth Gate", actor: "Next.js Middleware",
    description: "Before checkout, verify the user is logged in. Use Next.js middleware to redirect unauthenticated users to /login with a returnUrl param.",
    code: `// middleware.ts
export function middleware(req) {
  const session = getSession(req)
  if (!session && req.nextUrl.pathname === '/checkout') {
    return NextResponse.redirect('/login?returnUrl=/checkout')
  }
}`,
    warnings: ["Never skip this - guest checkout is a fraud vector."],
  },
  {
    id: 3, phase: "Server", color: "#10b981",
    title: "Create Payment Intent", actor: "API Route -> Stripe",
    description: "POST /api/checkout with cart items. Server validates prices against DB (never trust client-side prices), calculates total, creates a Stripe PaymentIntent, returns client_secret.",
    code: `// POST /api/checkout
const items = await db.products.findMany({
  where: { id: { in: cartItemIds } }
})
const total = items.reduce((s, i) => s + i.price_cents * qty, 0)

const intent = await stripe.paymentIntents.create({
  amount: total,
  currency: 'usd',
  metadata: { userId, cartHash }
})
return { clientSecret: intent.client_secret }`,
    warnings: ["Critical: recalculate price server-side.", "Use idempotency keys on Stripe calls."],
  },
  {
    id: 4, phase: "Browser", color: "#f59e0b",
    title: "Stripe Payment Form", actor: "Browser + Stripe Elements",
    description: "Render Stripe's hosted Elements UI. Card data goes directly to Stripe's servers - never touches yours. This is how you stay PCI compliant.",
    code: `// checkout-form.tsx
import { PaymentElement, useStripe } from '@stripe/react-stripe-js'

export function CheckoutForm() {
  const stripe = useStripe()
  const handleSubmit = async (e) => {
    e.preventDefault()
    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: { return_url: '/order-complete' }
    })
    if (error) setError(error.message)
  }
  return <form onSubmit={handleSubmit}><PaymentElement /></form>
}`,
    warnings: [],
  },
  {
    id: 5, phase: "Webhook", color: "#ec4899",
    title: "Fulfill the Order", actor: "Stripe Webhook -> API",
    description: "Stripe calls your /api/webhooks/stripe endpoint when payment succeeds. Verify the signature, then create the order record, decrement inventory, and trigger confirmation email.",
    code: `// POST /api/webhooks/stripe
const sig = req.headers['stripe-signature']
const event = stripe.webhooks.constructEvent(
  rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET
)
if (event.type === 'payment_intent.succeeded') {
  const intent = event.data.object
  await db.$transaction([
    db.orders.create({ data: buildOrder(intent) }),
    db.products.updateMany({ /* decrement inventory */ }),
  ])
  await resend.send(orderConfirmationEmail(intent.metadata.userId))
}`,
    warnings: ["Always verify webhook signature.", "Make webhook handlers idempotent."],
  },
  {
    id: 6, phase: "Post-purchase", color: "#8b5cf6",
    title: "Confirmation + Email", actor: "Browser + Resend",
    description: "Stripe redirects the browser to /order-complete. Fetch order status from your DB (your DB is the source of truth). Resend fires the confirmation email from the webhook.",
    code: `// /order-complete page
const order = await db.orders.findFirst({
  where: { stripe_payment_intent_id: intentId }
})
// Show order summary from DB, not Stripe response`,
    warnings: [],
  },
];

const phases = [
  {
    phase: "Phase 1", range: "$0 - ~$5k MRR", color: "#10b981",
    title: "Launch & Validate", users: "0 - 500 users",
    infra: "Vercel hobby/pro + Neon free + Upstash free", monthlyCost: "~$0-50/mo",
    actions: [
      "Single Next.js monorepo - frontend, API, admin all in one",
      "Neon serverless Postgres - scales to zero, free branching",
      "No Redis yet - use in-memory caching or Next.js unstable_cache",
      "Deploy to Vercel with a single git push",
      "Use Stripe's test mode until you're ready to go live",
      "Manual order fulfillment is fine at this scale",
    ],
    watchFor: "If p95 API latency > 2s or DB connections spike, move to Phase 2.",
  },
  {
    phase: "Phase 2", range: "$5k - $50k MRR", color: "#f59e0b",
    title: "Optimize & Stabilize", users: "500 - 10k users",
    infra: "Vercel Pro + Neon paid + Upstash + Algolia", monthlyCost: "~$100-500/mo",
    actions: [
      "Add Upstash Redis for session caching and rate limiting",
      "Add Algolia (or Typesense) for product search",
      "Move to Neon paid plan for connection pooling",
      "Add Sentry for error tracking, set up alerts",
      "Set up Playwright E2E tests for checkout",
      "Add a staging environment that mirrors production",
      "Start tracking Core Web Vitals",
    ],
    watchFor: "If Vercel bills exceed ~$500/mo or you need background jobs, move to Phase 3.",
  },
  {
    phase: "Phase 3", range: "$50k - $500k MRR", color: "#6366f1",
    title: "Scale & Decouple", users: "10k - 100k users",
    infra: "Vercel + separate API service + dedicated Postgres", monthlyCost: "~$500-3k/mo",
    actions: [
      "Extract API into a separate service (Node/Fastify on Railway or Fly.io)",
      "Move to dedicated Postgres with read replicas for analytics",
      "Add a job queue (BullMQ or Inngest) for async work",
      "Implement database connection pooling at the app layer",
      "Add a dedicated search cluster",
      "Consider a CDN image optimization layer",
      "Hire your first DevOps/backend engineer",
    ],
    watchFor: "At this scale, your bottleneck is almost always the DB. Profile queries regularly.",
  },
  {
    phase: "Phase 4", range: "$500k+ MRR", color: "#ec4899",
    title: "Enterprise & Resilience", users: "100k+ users",
    infra: "Multi-region, dedicated infrastructure", monthlyCost: "~$3k+/mo",
    actions: [
      "Multi-region deployment (Vercel + Fly.io regions)",
      "Database sharding or move to CockroachDB for horizontal scale",
      "Separate microservices for: payments, inventory, notifications, search",
      "Build an internal ops dashboard for CS and finance teams",
      "Dedicated security review and penetration testing",
      "SLA agreements with your infra providers",
      "Chaos engineering - simulate failures before they happen",
    ],
    watchFor: "You need a full engineering team at this point. Solo scaling ends here.",
  },
];

const securitySections = [
  {
    title: "Authentication & Sessions", color: "#6366f1", icon: "Auth",
    items: [
      { text: "Use Auth.js or Clerk - never roll your own auth", critical: true },
      { text: "Enforce HTTPS everywhere", critical: true },
      { text: "Set secure, httpOnly, sameSite cookies for sessions", critical: true },
      { text: "Implement rate limiting on /login and /register", critical: true },
      { text: "Add MFA option for seller accounts", critical: false },
      { text: "Rotate secrets quarterly", critical: false },
    ],
  },
  {
    title: "Payments & Financial", color: "#10b981", icon: "Pay",
    items: [
      { text: "Never store raw card numbers - use Stripe Elements only", critical: true },
      { text: "Always recalculate order totals server-side", critical: true },
      { text: "Verify Stripe webhook signatures on every request", critical: true },
      { text: "Use idempotency keys on all Stripe API calls", critical: true },
      { text: "Enable Stripe Radar (fraud detection)", critical: false },
      { text: "Monitor for unusual order patterns", critical: false },
      { text: "Test refund and dispute flows before going live", critical: false },
    ],
  },
  {
    title: "API & Input Validation", color: "#f59e0b", icon: "API",
    items: [
      { text: "Validate all inputs with Zod on every API route", critical: true },
      { text: "Never trust client-provided IDs for authorization checks", critical: true },
      { text: "Check that the user owns the resource before every mutation", critical: true },
      { text: "Add rate limiting to all public API routes", critical: true },
      { text: "Sanitize rich text / HTML inputs to prevent XSS", critical: true },
      { text: "Disable detailed error messages in production", critical: false },
      { text: "Add request logging for audit trails", critical: false },
    ],
  },
  {
    title: "Infrastructure & Data", color: "#ec4899", icon: "Infra",
    items: [
      { text: "Store secrets in environment variables - never in source code", critical: true },
      { text: "Enable automated DB backups", critical: true },
      { text: "Restrict DB access to your app's IP / VPC only", critical: true },
      { text: "Use row-level security (RLS) for multi-tenant data", critical: true },
      { text: "Scan for secret leaks in CI", critical: false },
      { text: "Set Content-Security-Policy and security headers", critical: false },
      { text: "Enable Cloudflare WAF rules for SQLi, XSS, bot protection", critical: false },
    ],
  },
  {
    title: "Compliance", color: "#8b5cf6", icon: "Legal",
    items: [
      { text: "Display Privacy Policy and Terms of Service before launch", critical: true },
      { text: "Add cookie consent banner for EU users (GDPR)", critical: true },
      { text: "Implement data deletion flow for account closure", critical: true },
      { text: "Don't log PII in application logs", critical: false },
      { text: "Check sales tax obligations (TaxJar or Stripe Tax)", critical: false },
      { text: "Document your data retention policy", critical: false },
    ],
  },
];

function SchemaTab() {
  const [active, setActive] = useState("users");
  const table = tables.find((t) => t.name === active);
  return (
    <div className="responsive-stack" style={{ display: "flex", gap: 16 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 6, width: 160, flexShrink: 0 }}>
        {tables.map((t) => (
          <button key={t.name} className="click-scale" onClick={() => setActive(t.name)} style={{
            background: active === t.name ? t.color + "22" : "#1a1a1f",
            border: `1px solid ${active === t.name ? t.color : "#2d2d35"}`,
            borderRadius: 8, padding: "10px 14px", textAlign: "left",
            cursor: "pointer", color: active === t.name ? t.color : "#9ca3af",
            fontFamily: "'DM Mono', monospace", fontSize: 12, fontWeight: 700,
            letterSpacing: 0.3, transition: "all 0.12s",
            boxShadow: active === t.name ? `0 0 10px ${t.color}30` : "none",
          }}>
            {t.name}
          </button>
        ))}
        <div style={{ marginTop: 8, padding: "10px 14px", background: "#111114", borderRadius: 8, border: "1px solid #1f1f24" }}>
          <div style={{ fontSize: 10, color: "#4b5563", marginBottom: 6, letterSpacing: 1 }}>RELATIONS</div>
          <div style={{ fontSize: 10, color: "#6b7280", lineHeight: 1.8, fontFamily: "'DM Mono', monospace" }}>
            users &larr; stores<br />
            stores &larr; products<br />
            users &larr; orders<br />
            orders &larr; order_items<br />
            products &larr; order_items<br />
            products &larr; reviews
          </div>
        </div>
      </div>

      {table && (
        <div style={{ flex: 1 }}>
          <div style={{ marginBottom: 12 }}>
            <span style={{ fontSize: 18, fontWeight: 800, color: table.color, fontFamily: "'DM Mono', monospace" }}>{table.name}</span>
            <p style={{ color: "#9ca3af", fontSize: 12, margin: "6px 0 0" }}>{table.desc}</p>
          </div>
          <div style={{ background: "#111114", borderRadius: 10, border: "1px solid #2d2d35", overflow: "hidden" }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 2fr", background: "#0d0d10", padding: "8px 14px", borderBottom: "1px solid #2d2d35" }}>
              {["column", "type", "notes"].map(h => (
                <span key={h} style={{ fontSize: 10, color: "#4b5563", letterSpacing: 2, textTransform: "uppercase", fontFamily: "'DM Mono', monospace" }}>{h}</span>
              ))}
            </div>
            {table.columns.map((col, i) => (
              <div key={col.name} style={{
                display: "grid", gridTemplateColumns: "1fr 1fr 2fr",
                padding: "10px 14px", borderBottom: i < table.columns.length - 1 ? "1px solid #1f1f24" : "none",
                background: i % 2 === 0 ? "transparent" : "#0f0f12",
              }}>
                <span style={{ fontSize: 12, color: "#e2e8f0", fontFamily: "'DM Mono', monospace", fontWeight: 600 }}>{col.name}</span>
                <span style={{ fontSize: 11, color: table.color, fontFamily: "'DM Mono', monospace" }}>{col.type}</span>
                <span style={{ fontSize: 11, color: "#6b7280" }}>{col.note}</span>
              </div>
            ))}
          </div>
          <div style={{ marginTop: 10, padding: "10px 14px", background: "#0d1117", borderRadius: 8, border: "1px solid #1f2937", fontSize: 11, color: "#6b7280" }}>
            <strong style={{ color: "#9ca3af" }}>Key insight:</strong> Store money as <code style={{ color: "#10b981" }}>integer cents</code>, never floats. Snapshot product prices in order_items so receipts stay accurate even if the product price changes later.
          </div>
        </div>
      )}
    </div>
  );
}

function CheckoutTab() {
  const [active, setActive] = useState(1);
  const step = checkoutSteps.find(s => s.id === active);
  return (
    <div>
      <div style={{ display: "flex", alignItems: "center", marginBottom: 24, gap: 0 }}>
        {checkoutSteps.map((s, i) => (
          <div key={s.id} style={{ display: "flex", alignItems: "center", flex: 1 }}>
            <button onClick={() => setActive(s.id)} style={{
              width: 36, height: 36, borderRadius: "50%", border: `2px solid ${active === s.id ? s.color : "#2d2d35"}`,
              background: active === s.id ? s.color : "#1a1a1f", color: active === s.id ? "#fff" : "#6b7280",
              fontWeight: 800, fontSize: 13, cursor: "pointer", flexShrink: 0, transition: "all 0.15s",
              fontFamily: "'DM Mono', monospace",
            }}>{s.id}</button>
            {i < checkoutSteps.length - 1 && (
              <div style={{ flex: 1, height: 2, background: active > s.id ? step?.color || "#2d2d35" : "#2d2d35", transition: "background 0.3s" }} />
            )}
          </div>
        ))}
      </div>

      {step && (
        <div>
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 6 }}>
              <span style={{ fontSize: 10, color: step.color, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700, background: step.color + "20", padding: "3px 8px", borderRadius: 4 }}>{step.phase}</span>
              <span style={{ fontSize: 11, color: "#4b5563" }}>Actor: {step.actor}</span>
            </div>
            <h3 style={{ fontSize: 18, fontWeight: 800, color: "#f1f5f9", margin: "0 0 8px", letterSpacing: -0.5 }}>{step.title}</h3>
            <p style={{ fontSize: 13, color: "#94a3b8", lineHeight: 1.7, margin: 0 }}>{step.description}</p>
          </div>

          {step.warnings.length > 0 && (
            <div style={{ marginBottom: 14 }}>
              {step.warnings.map((w, i) => (
                <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start", padding: "10px 14px", background: "#1c1007", border: "1px solid #92400e", borderRadius: 8, marginBottom: 6 }}>
                  <span style={{ fontSize: 12, color: "#fbbf24" }}>{w}</span>
                </div>
              ))}
            </div>
          )}

          <div style={{ background: "#0d1117", borderRadius: 10, border: "1px solid #1f2937", overflow: "hidden" }}>
            <div style={{ padding: "8px 16px", background: "#111827", borderBottom: "1px solid #1f2937", display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{ display: "flex", gap: 5 }}>
                {["#ef4444","#f59e0b","#22c55e"].map(c => <div key={c} style={{ width: 10, height: 10, borderRadius: "50%", background: c }} />)}
              </div>
              <span style={{ fontSize: 11, color: "#4b5563", fontFamily: "'DM Mono', monospace" }}>code reference</span>
            </div>
            <pre style={{ padding: 16, margin: 0, fontSize: 11, color: "#a5f3fc", overflowX: "auto", lineHeight: 1.7, fontFamily: "'DM Mono', monospace", maxWidth: "100%" }}>
              {step.code}
            </pre>
          </div>

          <div style={{ display: "flex", justifyContent: "space-between", marginTop: 14 }}>
            <button onClick={() => setActive(Math.max(1, active - 1))} disabled={active === 1} style={{
              padding: "8px 18px", borderRadius: 8, border: "1px solid #2d2d35", background: active === 1 ? "#111114" : "#1a1a1f",
              color: active === 1 ? "#374151" : "#9ca3af", cursor: active === 1 ? "default" : "pointer", fontSize: 12, fontFamily: "'DM Mono', monospace",
            }}>Prev</button>
            <button onClick={() => setActive(Math.min(checkoutSteps.length, active + 1))} disabled={active === checkoutSteps.length} style={{
              padding: "8px 18px", borderRadius: 8, border: `1px solid ${active < checkoutSteps.length ? step.color : "#2d2d35"}`,
              background: active < checkoutSteps.length ? step.color + "22" : "#111114",
              color: active < checkoutSteps.length ? step.color : "#374151",
              cursor: active === checkoutSteps.length ? "default" : "pointer", fontSize: 12, fontFamily: "'DM Mono', monospace",
            }}>Next</button>
          </div>
        </div>
      )}
    </div>
  );
}

function ScalingTab() {
  const [active, setActive] = useState(0);
  const ph = phases[active];
  return (
    <div>
      <div className="responsive-grid-4" style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8, marginBottom: 20 }}>
        {phases.map((p, i) => (
          <button key={i} className="click-scale" onClick={() => setActive(i)} style={{
            padding: "12px 10px", borderRadius: 10, border: `1px solid ${active === i ? p.color : "#2d2d35"}`,
            background: active === i ? p.color + "18" : "#1a1a1f", cursor: "pointer", textAlign: "left", transition: "all 0.15s",
            boxShadow: active === i ? `0 0 10px ${p.color}30` : "none",
          }}>
            <div style={{ fontSize: 10, color: p.color, fontWeight: 700, letterSpacing: 1, textTransform: "uppercase", marginBottom: 3, fontFamily: "'DM Mono', monospace" }}>{p.phase}</div>
            <div style={{ fontSize: 11, color: active === i ? "#e2e8f0" : "#6b7280", fontWeight: 600 }}>{p.title}</div>
            <div style={{ fontSize: 10, color: "#4b5563", marginTop: 3 }}>{p.range}</div>
          </button>
        ))}
      </div>

      {ph && (
        <div>
          <div className="responsive-grid-3" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 18 }}>
            {[["Users", ph.users], ["Infrastructure", ph.infra], ["Est. Infra Cost", ph.monthlyCost]].map(([k, v]) => (
              <div key={k} style={{ background: "#111114", border: "1px solid #2d2d35", borderRadius: 8, padding: "12px 14px" }}>
                <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 4 }}>{k}</div>
                <div style={{ fontSize: 12, color: "#d1d5db", fontWeight: 600 }}>{v}</div>
              </div>
            ))}
          </div>

          <div style={{ marginBottom: 14 }}>
            <div style={{ fontSize: 11, color: ph.color, letterSpacing: 2, textTransform: "uppercase", marginBottom: 10, fontWeight: 700 }}>Actions for this phase</div>
            {ph.actions.map((a, i) => (
              <div key={i} style={{ display: "flex", gap: 10, alignItems: "flex-start", marginBottom: 8 }}>
                <div style={{ width: 20, height: 20, borderRadius: "50%", background: ph.color + "20", border: `1px solid ${ph.color}50`, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 10, color: ph.color, fontWeight: 700 }}>{i + 1}</div>
                <span style={{ fontSize: 13, color: "#d1d5db", lineHeight: 1.6 }}>{a}</span>
              </div>
            ))}
          </div>

          <div style={{ padding: "12px 16px", background: "#1a0f07", border: "1px solid #78350f", borderRadius: 8 }}>
            <span style={{ fontSize: 11, color: "#fbbf24" }}>Watch for: </span>
            <span style={{ fontSize: 12, color: "#d97706" }}>{ph.watchFor}</span>
          </div>
        </div>
      )}
    </div>
  );
}

function SecurityTab() {
  const [checked, setChecked] = useState({});
  const toggle = (key) => setChecked(c => ({ ...c, [key]: !c[key] }));
  const allItems = securitySections.flatMap(s => s.items);
  const doneCount = Object.values(checked).filter(Boolean).length;
  const pct = Math.round((doneCount / allItems.length) * 100);

  return (
    <div>
      <div style={{ background: "#111114", borderRadius: 10, padding: "14px 18px", marginBottom: 20, border: "1px solid #2d2d35" }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ fontSize: 12, color: "#9ca3af" }}>{doneCount} of {allItems.length} items completed</span>
          <span style={{ fontSize: 12, fontWeight: 700, color: pct === 100 ? "#10b981" : pct > 60 ? "#f59e0b" : "#ef4444" }}>{pct}%</span>
        </div>
        <div style={{ height: 6, background: "#1f1f24", borderRadius: 3, overflow: "hidden" }}>
          <div style={{ width: `${pct}%`, height: "100%", background: pct === 100 ? "#10b981" : pct > 60 ? "#f59e0b" : "#6366f1", borderRadius: 3, transition: "width 0.3s" }} />
        </div>
      </div>

      {securitySections.map((section) => (
        <div key={section.title} style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 13, color: section.color, fontWeight: 700, marginBottom: 10, display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ fontSize: 10, background: section.color + '20', color: section.color, padding: '2px 6px', borderRadius: 4, fontWeight: 700, letterSpacing: 1 }}>{section.icon}</span>
            {section.title}
          </div>
          {section.items.map((item, i) => {
            const key = `${section.title}_${i}`;
            const done = checked[key];
            return (
              <div key={i} className="click-scale" onClick={() => toggle(key)} style={{
                display: "flex", gap: 12, alignItems: "flex-start", padding: "10px 14px",
                background: done ? "#0f1f0f" : "#111114", borderRadius: 8, marginBottom: 6, cursor: "pointer",
                border: `1px solid ${done ? "#166534" : item.critical ? "#2d2d35" : "#1f1f24"}`,
                transition: "all 0.12s",
              }}>
                <div style={{
                  width: 18, height: 18, borderRadius: 4, border: `2px solid ${done ? "#10b981" : item.critical ? "#ef4444" : "#374151"}`,
                  background: done ? "#10b981" : "transparent", flexShrink: 0, marginTop: 1,
                  display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: "#fff",
                }}>{done ? "\u2713" : ""}</div>
                <div style={{ flex: 1 }}>
                  <span style={{ fontSize: 12, color: done ? "#6b7280" : "#d1d5db", textDecoration: done ? "line-through" : "none" }}>{item.text}</span>
                </div>
                {item.critical && !done && (
                  <span style={{ fontSize: 9, color: "#ef4444", background: "#1f0707", border: "1px solid #7f1d1d", padding: "2px 6px", borderRadius: 4, letterSpacing: 1, fontWeight: 700, flexShrink: 0 }}>CRITICAL</span>
                )}
              </div>
            );
          })}
        </div>
      ))}
    </div>
  );
}

export default function DeepDive() {
  const [tab, setTab] = useState("schema");

  return (
    <div style={{
      fontFamily: "'DM Mono', 'Fira Code', 'Courier New', monospace",
      background: "#0f0f11",
      minHeight: "100vh",
      padding: "28px 24px",
      color: "#e2e8f0",
    }}>
      <div style={{ maxWidth: 860, margin: "0 auto" }}>
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 3, textTransform: "uppercase", marginBottom: 6 }}>E-Commerce Architecture - Deep Dive</div>
          <h1 style={{ fontSize: 22, fontWeight: 800, color: "#f9fafb", margin: 0, letterSpacing: -0.5 }}>Technical Reference</h1>
        </div>

        <div className="nav-scroll" style={{ display: "flex", gap: 4, marginBottom: 24, background: "#111114", padding: 4, borderRadius: 10, border: "1px solid #1f1f24" }}>
          {TABS.map((t) => (
            <button key={t.id} className="click-scale" onClick={() => setTab(t.id)} style={{
              flex: "0 0 auto", padding: "9px 14px", borderRadius: 7, border: "none",
              background: tab === t.id ? "#1e1e26" : "transparent",
              color: tab === t.id ? "#e2e8f0" : "#6b7280",
              fontFamily: "'DM Mono', monospace", fontSize: 11, cursor: "pointer",
              fontWeight: tab === t.id ? 700 : 400, transition: "all 0.12s",
              boxShadow: tab === t.id ? "0 1px 4px #00000060, 0 0 12px rgba(99,102,241,0.15)" : "none",
              whiteSpace: "nowrap",
            }}>
              {t.label}
            </button>
          ))}
        </div>

        <div style={{ background: "#111114", borderRadius: 12, border: "1px solid #2d2d35", padding: 24 }}>
          {tab === "schema" && <SchemaTab />}
          {tab === "checkout" && <CheckoutTab />}
          {tab === "scaling" && <ScalingTab />}
          {tab === "security" && <SecurityTab />}
        </div>
      </div>
    </div>
  );
}
