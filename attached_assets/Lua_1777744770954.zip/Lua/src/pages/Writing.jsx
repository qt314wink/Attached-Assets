export default function Writing() {
  return (
    <div style={{
      maxWidth: 720,
      margin: '0 auto',
      padding: '48px 24px 80px',
    }}>
      <div style={{
        fontSize: 10,
        color: '#4b5563',
        letterSpacing: 3,
        textTransform: 'uppercase',
        marginBottom: 8,
      }}>
        Essay
      </div>

      <h1 style={{
        fontSize: 32,
        fontWeight: 800,
        color: '#f9fafb',
        lineHeight: 1.15,
        letterSpacing: -0.8,
        marginBottom: 8,
      }}>
        The Useful Villains Nobody Thanks
      </h1>

      <p style={{
        fontSize: 16,
        color: '#9ca3af',
        fontStyle: 'italic',
        marginBottom: 8,
      }}>
        On the people who break your system to save it
      </p>

      <p style={{
        fontSize: 13,
        color: '#4b5563',
        marginBottom: 40,
      }}>
        Jennipher Troup &middot; AI Systems Design &middot; 2025
      </p>

      <article style={{
        fontSize: 15,
        color: '#d1d5db',
        lineHeight: 1.85,
      }}>
        <p style={{ marginBottom: 24 }}>
          Every system has someone it officially disapproves of.
        </p>
        <p style={{ marginBottom: 24 }}>
          You know the type. The person who asks the question nobody asked -- because nobody wanted the meeting to go longer. The designer who keeps shipping "bad" components, not because they don't know better, but because the component the system officially approves keeps failing at the edges where their users actually live. The engineer who builds the workaround instead of waiting eighteen months for the roadmap to catch up to reality. The content strategist who rewrites legal copy without asking because the approved version was causing users to abandon the flow at 73%.
        </p>
        <p style={{ marginBottom: 24 }}>
          Disruptors, technically. Rule-breakers, formally. Load-bearing walls, actually.
        </p>
        <p style={{ marginBottom: 32 }}>
          Here's what design systems discourse gets persistently wrong: it treats divergence as failure. Someone goes off-system? Enforcement problem. Someone builds a workaround? Gap in documentation. The implicit model is always: if people just used the system correctly, the system would work correctly. Which is a beautiful, coherent, utterly unfalsifiable belief -- because every failure gets attributed to execution, never to the model.
        </p>
        <p style={{
          fontSize: 14,
          color: '#9ca3af',
          fontStyle: 'italic',
          marginBottom: 32,
          paddingLeft: 20,
          borderLeft: '2px solid #374151',
        }}>
          The troublemakers are running diagnostics nobody commissioned.
        </p>

        <h2 style={{ fontSize: 20, fontWeight: 700, color: '#f1f5f9', marginBottom: 16, marginTop: 48, letterSpacing: -0.3 }}>
          I. What a Workaround Actually Is
        </h2>
        <p style={{ marginBottom: 24 }}>
          Think about what a workaround is at the information-theoretic level. It's a signal that the approved path doesn't serve the actual terrain. It's a probe. The person who built it walked the official route, found it broken at kilometer seven, and made a new path -- and then got written up for path deviation. The organization got a free failure report and responded by trying to close the report.
        </p>
        <p style={{ marginBottom: 24 }}>
          This is not a culture failure. It's a systems design failure. Organizations routinely build the incentives for compliance and the punishment for feedback into the same role, then wonder why they only hear what they want to hear.
        </p>
        <p style={{ marginBottom: 24 }}>
          The useful villain thrives in exactly this gap. They're not saboteurs. They're not idealists who rejected the system on principle. They tried the system -- often harder than anyone else -- and when it failed them, they adapted. The adaptation looks messy from inside a spreadsheet. From inside a user's actual experience, it looks like the only thing that works.
        </p>

        <h2 style={{ fontSize: 20, fontWeight: 700, color: '#f1f5f9', marginBottom: 16, marginTop: 48, letterSpacing: -0.3 }}>
          II. The Pattern Scales
        </h2>
        <p style={{ marginBottom: 24 }}>
          This isn't only a design systems problem. The pattern holds wherever systems have official logics that diverge from ground-level reality.
        </p>

        <h3 style={{ fontSize: 15, fontWeight: 600, color: '#e2e8f0', marginBottom: 12, marginTop: 28 }}>In AI governance:</h3>
        <p style={{ marginBottom: 24 }}>
          The safety researcher who publishes a red-team finding before her organization is ready to acknowledge it. The prompt engineer who documents jailbreak patterns in a public repo so practitioners can understand the attack surface -- flagged immediately as a threat actor by the same institutions that benefit from the knowledge. The alignment team that builds behavioral guardrails into a model deployment that violates the product's own stated values, quietly, because the product team wouldn't ship them voluntarily.
        </p>
        <p style={{ marginBottom: 24, fontSize: 13, color: '#9ca3af', fontStyle: 'italic' }}>
          The tension: disclosure norms in AI safety are still forming. What reads as reckless in 2024 may read as responsible by 2027. The moral valence is time-dependent.
        </p>

        <h3 style={{ fontSize: 15, fontWeight: 600, color: '#e2e8f0', marginBottom: 12, marginTop: 28 }}>In education and curriculum design:</h3>
        <p style={{ marginBottom: 24 }}>
          The teacher who skips the standardized test prep unit and teaches the one thing she knows her class actually needs. The instructional designer who quietly builds an off-script trauma-informed module into a corporate compliance training because the official curriculum was causing re-traumatization and HR wouldn't return emails.
        </p>

        <h3 style={{ fontSize: 15, fontWeight: 600, color: '#e2e8f0', marginBottom: 12, marginTop: 28 }}>In civic and policy systems:</h3>
        <p style={{ marginBottom: 24 }}>
          The city planner who approves the informal market instead of shutting it down -- because the informal market is the only affordable food infrastructure in the district, and the approved vendor approval process takes fourteen months. The community health worker who prescribes rest, food, and stability when the intake form asks for medication compliance, because she can read the actual determinant of the patient's health outcome.
        </p>
        <p style={{
          fontSize: 14,
          color: '#9ca3af',
          fontStyle: 'italic',
          marginBottom: 32,
          paddingLeft: 20,
          borderLeft: '2px solid #374151',
        }}>
          Three times is a pattern. A pattern is information. Information is the only raw material that actually improves a system.
        </p>

        <h2 style={{ fontSize: 20, fontWeight: 700, color: '#f1f5f9', marginBottom: 16, marginTop: 48, letterSpacing: -0.3 }}>
          III. The Typology
        </h2>
        <p style={{ marginBottom: 24 }}>
          Not all divergence is equivalent. The useful villain is a specific functional type, and confusing them with adjacent types is how organizations destroy their own diagnostic infrastructure.
        </p>
        <p style={{ marginBottom: 24 }}>
          The useful villain differs from the <strong style={{ color: '#f1f5f9' }}>ideological defector</strong> in one critical way: they didn't leave the system's goals. They're still trying to serve the stated purpose. They're just operating on a terrain the system hasn't mapped yet.
        </p>
        <p style={{ marginBottom: 24 }}>
          They differ from the <strong style={{ color: '#f1f5f9' }}>opportunist</strong> in that their workaround doesn't extract value -- it creates it for someone who wasn't being served.
        </p>
        <p style={{ marginBottom: 24 }}>
          And they differ from the <strong style={{ color: '#f1f5f9' }}>martyr</strong> in that they're not trying to get caught. The martyr wants the confrontation. The useful villain would genuinely prefer the system just worked so they could stop doing this.
        </p>
        <p style={{
          fontSize: 14,
          color: '#9ca3af',
          fontStyle: 'italic',
          marginBottom: 32,
          paddingLeft: 20,
          borderLeft: '2px solid #374151',
        }}>
          The diagnostic test is simple and uncomfortable: when their workaround disappears, does the person it served get better or worse outcomes? If worse -- the system lost something it didn't know it needed.
        </p>

        <h2 style={{ fontSize: 20, fontWeight: 700, color: '#f1f5f9', marginBottom: 16, marginTop: 48, letterSpacing: -0.3 }}>
          IV. What the System Actually Needs to Do
        </h2>
        <p style={{ marginBottom: 24 }}>
          The organizations that suppress useful villains don't become more compliant. They become more brittle. The feedback loops that could have been diagnostic get closed. What emerges is a design system that looks excellent in Figma and functions beautifully in usability tests with recruited participants who read the prompts carefully and have reliable internet access and finished high school in English.
        </p>
        <p style={{ marginBottom: 24, fontSize: 13, color: '#9ca3af', fontStyle: 'italic' }}>
          You know the other word for that: fiction.
        </p>
        <p style={{ marginBottom: 24 }}>
          What's needed isn't tolerance for deviance. That's just a softer version of the same mistake -- still treating divergence as a problem to be managed rather than a signal to be read. What's needed is systems designed to expect to be wrong about the terrain and built with the observational infrastructure to find out where.
        </p>

        <h2 style={{ fontSize: 20, fontWeight: 700, color: '#f1f5f9', marginBottom: 16, marginTop: 48, letterSpacing: -0.3 }}>
          V. The Operational Provocation
        </h2>
        <p style={{ marginBottom: 24 }}>
          If you manage systems -- design systems, AI systems, educational systems, civic systems -- here is the single most diagnostic question you are probably not asking:
        </p>
        <p style={{
          fontSize: 16,
          color: '#f1f5f9',
          fontWeight: 600,
          marginBottom: 32,
          paddingLeft: 20,
          borderLeft: '3px solid #ec4899',
          lineHeight: 1.7,
        }}>
          Where in this system are people building workarounds, and what does the pattern of those workarounds tell us about who we forgot?
        </p>
        <p style={{ marginBottom: 24 }}>
          Not: how do we stop the workarounds. Not: how do we get compliance. Where are they, what's the pattern, and who isn't being served by the approved path.
        </p>
        <p style={{ marginBottom: 32 }}>
          The workaround is a gift. Expensive to give, easy to throw away. Most organizations throw it away and call the response governance.
        </p>

        <div style={{
          marginTop: 48,
          paddingTop: 32,
          borderTop: '1px solid #1f1f24',
        }}>
          <p style={{
            fontSize: 14,
            color: '#6b7280',
            fontStyle: 'italic',
            marginBottom: 24,
          }}>
            The best tools in the world don't fix a system that treats its own diagnostic signals as threats. The people running ahead of your documentation, bending your components, rewriting your copy, shipping the workaround -- they're not the problem. They're the system thinking.
          </p>
          <p style={{ fontSize: 14, color: '#6b7280', fontWeight: 600, marginBottom: 40 }}>
            Thank them quietly. Change the system loudly.
          </p>
        </div>

        <div style={{
          background: '#111114',
          border: '1px solid #1f1f24',
          borderRadius: 12,
          padding: 24,
          marginTop: 32,
        }}>
          <div style={{ fontSize: 11, color: '#4b5563', letterSpacing: 2, textTransform: 'uppercase', marginBottom: 16 }}>
            Appendix: The Useful Villain Framework
          </div>

          <div style={{ marginBottom: 20 }}>
            <h4 style={{ fontSize: 13, fontWeight: 700, color: '#e2e8f0', marginBottom: 8 }}>Identification Test</h4>
            <p style={{ fontSize: 13, color: '#9ca3af', lineHeight: 1.7 }}>
              When the useful villain's workaround disappears, do the people it served get better or worse outcomes? If worse: the system lost active infrastructure it didn't know it had.
            </p>
          </div>

          <div style={{ marginBottom: 20 }}>
            <h4 style={{ fontSize: 13, fontWeight: 700, color: '#e2e8f0', marginBottom: 8 }}>Differentiation from Adjacent Types</h4>
            <p style={{ fontSize: 13, color: '#9ca3af', lineHeight: 1.7 }}>
              The ideological defector changed goals. The opportunist extracted value from the gap. The martyr wants the confrontation. The useful villain has the same goals as the system, a more accurate map of the terrain, and no interest in being written up for the path they took.
            </p>
          </div>

          <div style={{ marginBottom: 20 }}>
            <h4 style={{ fontSize: 13, fontWeight: 700, color: '#e2e8f0', marginBottom: 8 }}>Organizational Diagnostic</h4>
            <p style={{ fontSize: 13, color: '#9ca3af', lineHeight: 1.7 }}>
              Count the workarounds. Map their location. Identify the pattern. Ask: what terrain was the official path not designed to cover? The workaround cluster is your system's honest self-report.
            </p>
          </div>

          <div>
            <h4 style={{ fontSize: 13, fontWeight: 700, color: '#e2e8f0', marginBottom: 8 }}>Design Implication</h4>
            <p style={{ fontSize: 13, color: '#9ca3af', lineHeight: 1.7 }}>
              Systems that want to learn must build divergence-observability into the tooling, not the audit process. Audit is forensic. Observability is live. The three-times-a-pattern rule should be native to the system, not buried in a retrospective nobody reads.
            </p>
          </div>
        </div>

        <div style={{
          marginTop: 32,
          fontSize: 12,
          color: '#4b5563',
          fontStyle: 'italic',
        }}>
          Jennipher Troup is an AI Systems Designer specializing in interaction design for constrained intelligence systems, behavioral architectures, and governance frameworks.
        </div>
      </article>
    </div>
  );
}
