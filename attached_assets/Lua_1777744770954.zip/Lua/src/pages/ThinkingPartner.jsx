import { useState, useRef, useEffect, useCallback } from "react";

const cognitiveLayerMeta = {
  context: { label: "Context", color: "#6366f1", description: "What you said vs. what you meant" },
  analysis: { label: "Analysis", color: "#0ea5e9", description: "Following the incentives, not the narrative" },
  challenge: { label: "Challenge", color: "#f59e0b", description: "The version where you're the blind spot" },
  synthesis: { label: "Synthesis", color: "#10b981", description: "Holding the tension without collapsing it" },
};

const cognitiveLayerOrder = ["context", "analysis", "challenge", "synthesis"];

const scenarios = {
  "default": {
    layers: {
      context: {
        thoughts: [
          "Reading the question you typed, but also the question underneath the question...",
          "Checking which parts of the framing protect you from an answer you already suspect...",
          "Mapping what you chose to include vs. what you left out -- the omission is the tell...",
        ],
        insight: "You already know something about this. The fact that you're asking means the knowing isn't the problem -- it's that the knowing is inconvenient. Most questions aren't requests for information. They're requests for permission to act on information you already have but wish you didn't.",
        confidence: 71,
      },
      analysis: {
        thoughts: [
          "Separating the thing you said from the thing you meant from the thing you're avoiding...",
          "Tracing which part of this is fear dressed up as 'being reasonable'...",
          "Checking whether your constraints are real or just familiar...",
        ],
        insight: "Here's what's funny: you framed this as a thinking problem, but your body already solved it. You're not stuck because you can't figure it out. You're stuck because figuring it out means you'd have to do something about it, and the doing is the part that costs.",
        confidence: 64,
      },
      challenge: {
        thoughts: [
          "Testing the story you told yourself against the story you'd tell someone you trust at 2am...",
          "Looking for the version of this where you're not the protagonist but the obstacle...",
          "Checking: is this a problem to solve or a tension to hold? Not everything resolves.",
        ],
        insight: "The part of you that's irritated right now? That's the useful part. Irritation is the immune response of a belief system that just detected a foreign body. Don't suppress it -- follow it. It's pointing at the exact thing you've been stepping around. The discomfort isn't a bug. It's the signal you came here to find.",
        confidence: 59,
      },
      synthesis: {
        thoughts: [
          "Refusing to collapse this into a clean answer because the mess IS the answer...",
          "Holding the tension between what you want to be true and what keeps showing up...",
          "Noting what can't be falsified here -- and what that unfalsifiability is protecting...",
        ],
        insight: "You don't need a better answer. You need a higher tolerance for the answer you've got. The paradox isn't a flaw in your reasoning -- it's the shape of the actual situation. Some things are genuinely both true at once. The skill isn't resolving the contradiction. It's building a self that can hold contradictions without needing to pick a side or leave the room.",
        confidence: 73,
      },
    },
    socraticQuestions: [
      "What's the version of this problem where you're the one causing it? Not because you are -- but because that version is the only one where you have any power.",
      "You've described what you think about this. What do you feel about it? And before you answer -- notice whether you just translated the feeling back into a thought.",
      "If the answer turned out to be something you'd be embarrassed to admit, would you still want it? That hesitation is worth more than any analysis.",
    ],
  },
  "team": {
    layers: {
      context: {
        thoughts: [
          "Noticing you described people, not incentives. That's the first tell...",
          "Mapping what gets rewarded vs. what gets said at all-hands. Those are never the same list...",
          "Checking whether 'the team problem' is actually 'my problem with the team'...",
        ],
        insight: "You called it a team problem. But here's the thing about team problems: everyone on the team also thinks it's a team problem, and every single one of them means a different team. The person you're frustrated with? They have an equally coherent story where you're the difficult one. Neither of you is wrong. That's what makes it structural, not personal.",
        confidence: 77,
      },
      analysis: {
        thoughts: [
          "Tracing the incentive architecture -- people aren't broken, their reward functions are...",
          "Checking whether 'poor communication' is doing all the work of a real diagnosis...",
          "Mapping who can't afford to be honest and why...",
        ],
        insight: "Everyone says the problem is communication. It's never communication. 'Communication problem' is the polite fiction teams use when the real issue is that being honest would cost someone something. People aren't failing to communicate. They're communicating exactly what's safe to communicate, and that list is shorter than anyone admits. The silence is the message.",
        confidence: 72,
      },
      challenge: {
        thoughts: [
          "Testing: what if the 'difficult person' is the only one not performing?...",
          "Examining who benefits from the current dysfunction -- dysfunction always has beneficiaries...",
          "Checking whether your frustration is about their behavior or your need for them to agree...",
        ],
        insight: "Let's sit with an uncomfortable one: what if the person you find most difficult is the only one telling you the truth? Not nicely. Not tactfully. Maybe badly. But accurately. Teams punish honesty all the time and then wonder why nobody speaks up. You might be looking at someone whose only crime is a low tolerance for the performance everyone else agreed to.",
        confidence: 63,
      },
      synthesis: {
        thoughts: [
          "Refusing to recommend 'better communication' because that's not a plan, it's a wish...",
          "Holding the tension: you want the team to change but you might be what the team is adapting to...",
          "Looking for what's actually movable vs. what you've been pushing on because it feels productive...",
        ],
        insight: "You don't have a people problem. You have a system that makes certain behaviors rational. Fix the system and the people will look like different people. Or -- and this is the part nobody wants to hear -- you're part of the system too. The way you're describing this situation is itself a data point about why the situation exists. That's not an attack. It's an invitation to be curious about your own role in the pattern you're trying to change.",
        confidence: 69,
      },
    },
    socraticQuestions: [
      "Describe the problem person's perspective as generously as you can -- like you're their defense attorney. Where did you get stuck? That's where your blind spot lives.",
      "What would this team do differently if nobody was watching and there were no consequences? The gap between that answer and today is the measure of how much performance tax everyone is paying.",
      "You want the team to be more honest. Are you being honest right now? What's the thing you haven't said to them that you just said to a text box?",
    ],
  },
  "career": {
    layers: {
      context: {
        thoughts: [
          "Noticing you framed this as a decision, but decisions imply options. Let's check if you actually have options or just the fear of admitting you've already chosen...",
          "Separating what you want from what you think you should want -- those two have different landlords...",
          "Checking whose voice is actually doing the talking when you say 'I should'...",
        ],
        insight: "You said career, but you meant identity. Nobody lies awake at 3am thinking about job titles. They lie awake thinking: am I wasting the only life I get? Is this who I am or who I settled for? That's not a career question. It's an existential one wearing a LinkedIn outfit. And it doesn't have a five-step answer, no matter how many career coaches tell you it does.",
        confidence: 68,
      },
      analysis: {
        thoughts: [
          "Mapping what you actually do with unstructured time vs. what you say you'd do 'if only'...",
          "Checking whether 'I don't know what I want' is true or just safer than admitting what you want...",
          "Tracing who taught you what a 'good career' looks like and whether they were happy...",
        ],
        insight: "Here's a test that's annoyingly accurate: look at what you do when nobody's evaluating you. Not what you say you'd do. What you actually did last Saturday. Last month's browser history. The things you explain to people at parties with a little too much energy. That's the signal. Everything else is the story you're telling to make the signal socially acceptable or economically rational.",
        confidence: 74,
      },
      challenge: {
        thoughts: [
          "Testing whether 'I need more information before I decide' is actually 'I need more time before I'm brave enough'...",
          "Examining the cost of staying, not just the risk of leaving. Inaction has a price too, it's just quieter...",
          "Checking: are you afraid of failing, or afraid of succeeding at something that would prove the last five years were optional?...",
        ],
        insight: "The fear isn't about the new thing. It's about what choosing the new thing says about the old thing. If you leave and thrive, it means you could have left three years ago. That retroactive regret is the real monster under the bed. So you stay, not because staying is good, but because staying doesn't require you to grieve the time you already spent. Sunk cost isn't just a fallacy. It's an identity protection mechanism.",
        confidence: 61,
      },
      synthesis: {
        thoughts: [
          "Holding two truths at once: you can be grateful for what you have AND know it's not enough...",
          "Refusing to tell you to 'follow your passion' because passion is a symptom, not a compass...",
          "Noting that the question itself is the answer -- people who are where they belong don't ask this...",
        ],
        insight: "I'm not going to tell you what to do. But I will tell you this: the fact that you're asking is not neutral. Happy people don't wonder if they should be somewhere else. That doesn't mean leave tomorrow. It means stop pretending the wondering is just idle curiosity. It's not. It's a signal, and you've been treating it like noise because noise is easier to live with. You can keep doing that. But the signal doesn't get quieter. It gets more expensive.",
        confidence: 70,
      },
    },
    socraticQuestions: [
      "Finish this sentence without thinking: 'If I didn't have to worry about money or what people think, I would...' -- now look at what you said. Why aren't you doing a small version of that right now?",
      "Who would be disappointed if you made the change you're considering? Are you living your life or managing their expectations? When did those become the same project?",
      "You've been 'thinking about this for a while.' What's the longest you've thought about something before actually doing it? And at what point did thinking become the thing you do instead of the thing?",
    ],
  },
  "product": {
    layers: {
      context: {
        thoughts: [
          "Noting you described the product before you described the person using it. That's diagnostic...",
          "Checking whether 'what should we build' is masking 'what do I need to be true about my users'...",
          "Mapping the gap between your roadmap and your users' actual pain -- those overlap less than you think...",
        ],
        insight: "You're thinking about your product. Your users are not. They're thinking about their problem, and your product is -- at best -- something they tolerate on the way to solving it. That's not a failure. That's just reality. But it means every minute you spend making your product 'better' without watching someone actually struggle with the problem is a minute spent polishing a guess.",
        confidence: 76,
      },
      analysis: {
        thoughts: [
          "Tracing where users quit, curse, or build workarounds -- that's the actual product map...",
          "Checking whether your metrics measure what you want to believe or what's actually happening...",
          "Separating 'users want this' from 'users said this when we asked leading questions in a survey'...",
        ],
        insight: "Your users are lying to you and it's not their fault. When you ask people what they want, they tell you a better version of what they already have. Nobody asked for the iPhone. They asked for a better Blackberry keyboard. The workarounds your users build when they think nobody's watching are worth more than a thousand survey responses. Behavior is the only honest product research.",
        confidence: 81,
      },
      challenge: {
        thoughts: [
          "Testing: are you building this feature because users need it, or because your competitor has it and you're scared?...",
          "Examining whether your product vision is a hypothesis or an emotional attachment you're protecting with data...",
          "Checking if 'our users love us' means they love you or they just haven't found the alternative yet...",
        ],
        insight: "Here's the question that makes product people flinch: what if your product isn't as important as you think it is? What if users use it because switching costs are high, not because value is high? Loyalty and inertia look identical from the dashboard. The only way to tell the difference is to make it easy to leave and see who stays. Almost nobody runs that test, and the reason they don't is the reason they should.",
        confidence: 58,
      },
      synthesis: {
        thoughts: [
          "Holding the tension: you need to believe in what you're building AND remain willing to be wrong about it...",
          "Refusing to give you a feature recommendation because that would be me guessing about your users from here...",
          "Noting that the best product instinct is the willingness to be embarrassed by your own assumptions...",
        ],
        insight: "Stop adding features. Go sit with a user for an hour. Not a call. Not a survey. Sit next to them and shut up. Watch where they hesitate. Watch what they ignore. Watch what they do right after they close your app. That hour will be more uncomfortable and more useful than your entire product roadmap, and the reason you haven't done it yet is the same reason you need to.",
        confidence: 74,
      },
    },
    socraticQuestions: [
      "If your product disappeared tomorrow, what would users actually miss vs. what would they just replace with something else by Thursday? Be honest -- that gap is your real value prop.",
      "When was the last time a user told you something about your product that genuinely surprised you? If it's been more than a month, you've stopped listening and started confirming.",
      "You're building for the user you understand. What about the user who tried your product and left without telling you why? They're not in your data. They're in your blind spot. What would it take to go find them?",
    ],
  },
};

function classifyInput(text) {
  const lower = text.toLowerCase();
  if (/(team|colleague|manager|coworker|meeting|leadership|culture|hire|firing|conflict|collaborate)/i.test(lower)) return "team";
  if (/(career|job|role|quit|salary|promotion|interview|resume|hire me|should i stay|skill|transition)/i.test(lower)) return "career";
  if (/(product|feature|user|customer|ship|build|mvp|roadmap|launch|metric|retention|churn|onboard)/i.test(lower)) return "product";
  return "default";
}

let audioCtx = null;
function getAudioCtx() {
  if (!audioCtx && typeof window !== "undefined") {
    audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  return audioCtx;
}

function playSound(type) {
  const ctx = getAudioCtx();
  if (!ctx) return;
  try {
    if (ctx.state === "suspended") ctx.resume();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);

    const now = ctx.currentTime;
    if (type === "tick") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.exponentialRampToValueAtTime(1200, now + 0.05);
      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
      osc.start(now);
      osc.stop(now + 0.1);
    } else if (type === "layer") {
      osc.type = "triangle";
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(660, now + 0.15);
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === "insight") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(523, now);
      gain.gain.setValueAtTime(0.07, now);
      const osc2 = ctx.createOscillator();
      osc2.type = "sine";
      osc2.frequency.setValueAtTime(659, now);
      osc2.connect(gain);
      osc.start(now);
      osc2.start(now + 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);
      osc.stop(now + 0.5);
      osc2.stop(now + 0.5);
    } else if (type === "question") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(392, now);
      osc.frequency.exponentialRampToValueAtTime(523, now + 0.2);
      gain.gain.setValueAtTime(0.05, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.start(now);
      osc.stop(now + 0.35);
    } else if (type === "submit") {
      osc.type = "sine";
      osc.frequency.setValueAtTime(261, now);
      osc.frequency.exponentialRampToValueAtTime(523, now + 0.12);
      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc.start(now);
      osc.stop(now + 0.2);
    }
  } catch (e) {}
}

function AnimatedText({ text, delay = 0, speed = 25, style, onComplete }) {
  const [displayed, setDisplayed] = useState("");
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setStarted(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);

  useEffect(() => {
    if (!started) return;
    let i = 0;
    setDisplayed("");
    const interval = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) {
        clearInterval(interval);
        if (onComplete) onComplete();
      }
    }, speed);
    return () => clearInterval(interval);
  }, [started, text, speed]);

  if (!started) return null;

  return (
    <span style={{ ...style }}>
      {displayed}
      {displayed.length < text.length && (
        <span style={{
          display: "inline-block",
          width: 2,
          height: "1em",
          background: style?.color || "#6b7280",
          marginLeft: 2,
          animation: "blink 0.8s step-end infinite",
          verticalAlign: "text-bottom",
        }} />
      )}
    </span>
  );
}

function ConfidenceRing({ value, color, size = 52, delay = 0 }) {
  const [animValue, setAnimValue] = useState(0);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);

  useEffect(() => {
    if (!visible) return;
    let frame;
    let start;
    const duration = 800;
    const animate = (ts) => {
      if (!start) start = ts;
      const progress = Math.min((ts - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setAnimValue(Math.round(eased * value));
      if (progress < 1) frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frame);
  }, [visible, value]);

  if (!visible) return <div style={{ width: size, height: size }} />;

  const radius = (size - 6) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (animValue / 100) * circumference;

  return (
    <div style={{ position: "relative", width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: "rotate(-90deg)" }}>
        <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke="#1f1f24" strokeWidth={4} />
        <circle cx={size/2} cy={size/2} r={radius} fill="none" stroke={color} strokeWidth={4}
          strokeDasharray={circumference} strokeDashoffset={offset}
          strokeLinecap="round" style={{ transition: "stroke-dashoffset 0.1s" }} />
      </svg>
      <div style={{
        position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 13, fontWeight: 800, color, fontFamily: "'DM Mono', monospace",
      }}>
        {animValue}
      </div>
    </div>
  );
}

function PulsingDot({ color, size = 8, delay = 0 }) {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const t = setTimeout(() => setVisible(true), delay);
    return () => clearTimeout(t);
  }, [delay]);
  if (!visible) return null;
  return (
    <span style={{
      display: "inline-block", width: size, height: size, borderRadius: "50%",
      background: color, animation: "pulse 2s ease-in-out infinite",
      boxShadow: `0 0 8px ${color}60`,
    }} />
  );
}

export default function ThinkingPartner() {
  const [input, setInput] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [query, setQuery] = useState("");
  const [activeLayer, setActiveLayer] = useState(-1);
  const [completedLayers, setCompletedLayers] = useState([]);
  const [showSocratic, setShowSocratic] = useState(false);
  const [scenario, setScenario] = useState(null);
  const [layerThoughts, setLayerThoughts] = useState({});
  const [showInsight, setShowInsight] = useState({});
  const resultRef = useRef(null);
  const [soundEnabled, setSoundEnabled] = useState(true);

  const sound = useCallback((type) => {
    if (soundEnabled) playSound(type);
  }, [soundEnabled]);

  const startThinking = useCallback((text) => {
    if (!text.trim()) return;
    sound("submit");
    const classified = classifyInput(text);
    setScenario(scenarios[classified]);
    setQuery(text);
    setInput(text);
    setSubmitted(true);
    setActiveLayer(-1);
    setCompletedLayers([]);
    setShowSocratic(false);
    setLayerThoughts({});
    setShowInsight({});

    setTimeout(() => {
      setActiveLayer(0);
      sound("layer");
    }, 600);
  }, [sound]);

  const handleSubmit = (e) => {
    e.preventDefault();
    startThinking(input);
  };

  useEffect(() => {
    if (activeLayer < 0 || !scenario) return;
    const layerId = cognitiveLayerOrder[activeLayer];
    if (!layerId) return;

    const thoughts = scenario.layers[layerId].thoughts;
    let i = 0;
    const showNextThought = () => {
      if (i < thoughts.length) {
        setLayerThoughts(prev => ({
          ...prev,
          [layerId]: [...(prev[layerId] || []), thoughts[i]],
        }));
        sound("tick");
        i++;
        setTimeout(showNextThought, 700 + Math.random() * 500);
      } else {
        setTimeout(() => {
          setShowInsight(prev => ({ ...prev, [layerId]: true }));
          sound("insight");
          setCompletedLayers(prev => [...prev, layerId]);

          if (activeLayer < cognitiveLayerOrder.length - 1) {
            setTimeout(() => {
              setActiveLayer(prev => prev + 1);
              sound("layer");
            }, 1200);
          } else {
            setTimeout(() => {
              setShowSocratic(true);
              sound("question");
            }, 1500);
          }
        }, 500);
      }
    };

    const timer = setTimeout(showNextThought, 400);
    return () => clearTimeout(timer);
  }, [activeLayer, scenario]);

  useEffect(() => {
    if (resultRef.current) {
      resultRef.current.scrollTo({ top: resultRef.current.scrollHeight, behavior: "smooth" });
    }
  }, [activeLayer, layerThoughts, showInsight, showSocratic]);

  const handleReset = () => {
    setSubmitted(false);
    setInput("");
    setQuery("");
    setActiveLayer(-1);
    setCompletedLayers([]);
    setShowSocratic(false);
    setScenario(null);
    setLayerThoughts({});
    setShowInsight({});
  };

  const handleSocraticClick = (q) => {
    startThinking(q);
  };

  const suggestedQueries = [
    "Everyone on my team agrees we need to communicate better, but nothing changes",
    "I've been thinking about leaving my job for two years but I haven't done it",
    "We keep building features but I'm not sure anyone actually wants them",
    "I know what I should do but I keep not doing it",
  ];

  return (
    <div style={{
      background: "#0a0a0c",
      minHeight: "100vh",
      padding: "32px 24px",
      color: "#e2e8f0",
    }}>
      <style>{`
        @keyframes blink { 0%, 100% { opacity: 1 } 50% { opacity: 0 } }
        @keyframes pulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.6; transform: scale(1.3); } }
        @keyframes fadeSlideIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes expandIn { from { opacity: 0; transform: scale(0.95); max-height: 0; } to { opacity: 1; transform: scale(1); max-height: 500px; } }
        @keyframes glowPulse { 0%, 100% { box-shadow: 0 0 0px transparent; } 50% { box-shadow: 0 0 20px var(--glow-color); } }
        .fade-slide-in { animation: fadeSlideIn 0.4s ease-out forwards; }
        .expand-in { animation: expandIn 0.5s ease-out forwards; }
        input[type="range"]::-webkit-slider-thumb { -webkit-appearance: none; appearance: none; width: 14px; height: 14px; border-radius: 50%; background: #e2e8f0; cursor: pointer; border: 2px solid #0a0a0c; }
      `}</style>

      <div style={{ maxWidth: 800, margin: "0 auto" }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
            <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 3, textTransform: "uppercase" }}>
              Cognitive Architecture Demo
            </div>
            <button
              className="click-scale"
              onClick={() => setSoundEnabled(!soundEnabled)}
              style={{
                background: "none", border: "1px solid #2d2d35", borderRadius: 6,
                padding: "4px 10px", fontSize: 11, color: soundEnabled ? "#9ca3af" : "#4b5563",
                cursor: "pointer", fontFamily: "'DM Mono', monospace",
              }}
            >
              Sound {soundEnabled ? "On" : "Off"}
            </button>
          </div>
          <h1 style={{ fontSize: 28, fontWeight: 800, color: "#f9fafb", margin: "0 0 6px", letterSpacing: -0.5 }}>
            Thinking Partner
          </h1>
          <p style={{ fontSize: 14, color: "#6b7280", margin: 0, lineHeight: 1.7, maxWidth: 560 }}>
            Describe what's stuck. The system won't fix it for you -- it'll show you what you're avoiding, challenge the story you're telling yourself, and ask the questions you've been dodging. It rewards honesty, tolerates mess, and refuses to collapse tension into a clean answer.
          </p>
        </div>

        {!submitted && (
          <div>
            <form onSubmit={handleSubmit} style={{ marginBottom: 24 }}>
              <div style={{
                display: "flex", gap: 8,
                background: "#111114", borderRadius: 12, border: "1px solid #2d2d35",
                padding: 6, transition: "border-color 0.2s",
              }}>
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder="What's stuck?"
                  style={{
                    flex: 1, background: "none", border: "none", outline: "none",
                    color: "#e2e8f0", fontSize: 15, padding: "12px 14px",
                    fontFamily: "inherit",
                  }}
                />
                <button
                  type="submit"
                  disabled={!input.trim()}
                  className="click-scale"
                  style={{
                    padding: "10px 24px", borderRadius: 8,
                    background: input.trim() ? "#6366f1" : "#1f1f24",
                    border: "none", color: input.trim() ? "#fff" : "#4b5563",
                    fontSize: 13, fontWeight: 700, cursor: input.trim() ? "pointer" : "default",
                    fontFamily: "inherit",
                    boxShadow: input.trim() ? "0 0 12px rgba(99,102,241,0.2)" : "none",
                  }}
                >
                  Think
                </button>
              </div>
            </form>

            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 10, color: "#374151", letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>
                Try one of these
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {suggestedQueries.map((q, i) => (
                  <button
                    key={i}
                    className="click-scale"
                    onClick={() => { setInput(q); sound("tick"); }}
                    style={{
                      background: "#111114", border: "1px solid #1f1f24", borderRadius: 8,
                      padding: "12px 14px", textAlign: "left", cursor: "pointer",
                      color: "#9ca3af", fontSize: 13,
                      fontFamily: "inherit",
                    }}
                    onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#6366f180"; e.currentTarget.style.color = "#e2e8f0"; e.currentTarget.style.boxShadow = "0 0 12px rgba(99,102,241,0.12)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#1f1f24"; e.currentTarget.style.color = "#9ca3af"; e.currentTarget.style.boxShadow = "none"; }}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <div style={{
              background: "#111114", borderRadius: 12, border: "1px solid #1f1f24",
              padding: 20,
            }}>
              <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 2, textTransform: "uppercase", marginBottom: 14, fontWeight: 700 }}>
                How It Works
              </div>
              <div className="responsive-grid-4" style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
                {cognitiveLayerOrder.map((id) => {
                  const meta = cognitiveLayerMeta[id];
                  return (
                    <div key={id} style={{
                      background: "#0a0a0c", borderRadius: 8, padding: "14px 12px",
                      border: `1px solid ${meta.color}30`, textAlign: "center",
                    }}>
                      <PulsingDot color={meta.color} size={8} delay={cognitiveLayerOrder.indexOf(id) * 200} />
                      <div style={{ fontSize: 12, fontWeight: 700, color: meta.color, marginTop: 8, marginBottom: 4 }}>
                        {meta.label}
                      </div>
                      <div style={{ fontSize: 10, color: "#4b5563", lineHeight: 1.5 }}>
                        {meta.description}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {submitted && scenario && (
          <div>
            <div style={{
              background: "#111114", borderRadius: 12, border: "1px solid #2d2d35",
              padding: "16px 20px", marginBottom: 16, display: "flex",
              justifyContent: "space-between", alignItems: "center",
            }}>
              <div>
                <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 1, marginBottom: 4 }}>YOUR QUESTION</div>
                <div style={{ fontSize: 14, color: "#e2e8f0", fontWeight: 600 }}>{query}</div>
              </div>
              <button onClick={handleReset} className="click-scale" style={{
                background: "none", border: "1px solid #2d2d35", borderRadius: 6,
                padding: "6px 14px", color: "#6b7280", fontSize: 11, cursor: "pointer",
                fontFamily: "'DM Mono', monospace",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#6b728080"; e.currentTarget.style.color = "#9ca3af"; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#2d2d35"; e.currentTarget.style.color = "#6b7280"; }}
              >
                New question
              </button>
            </div>

            <div className="nav-scroll" style={{
              display: "flex", gap: 6, marginBottom: 16,
              background: "#111114", borderRadius: 10, padding: 4, border: "1px solid #1f1f24",
            }}>
              {cognitiveLayerOrder.map((id, i) => {
                const meta = cognitiveLayerMeta[id];
                const isActive = i === activeLayer;
                const isCompleted = completedLayers.includes(id);
                return (
                  <div key={id} style={{
                    flex: 1, padding: "8px 10px", borderRadius: 7, textAlign: "center",
                    background: isActive ? meta.color + "20" : isCompleted ? meta.color + "10" : "transparent",
                    border: `1px solid ${isActive ? meta.color + "60" : "transparent"}`,
                    transition: "all 0.3s ease",
                  }}>
                    <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}>
                      {isActive && <PulsingDot color={meta.color} size={6} />}
                      {isCompleted && <span style={{ fontSize: 10, color: meta.color }}>&#10003;</span>}
                      <span style={{
                        fontSize: 11, fontWeight: isActive ? 700 : 500,
                        color: isActive ? meta.color : isCompleted ? meta.color + "aa" : "#374151",
                        transition: "color 0.3s",
                      }}>
                        {meta.label}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div ref={resultRef} style={{
              maxHeight: "calc(100vh - 320px)", overflowY: "auto",
              display: "flex", flexDirection: "column", gap: 12,
              paddingRight: 4,
            }}>
              {cognitiveLayerOrder.map((id, i) => {
                const meta = cognitiveLayerMeta[id];
                const thoughts = layerThoughts[id] || [];
                const hasInsight = showInsight[id];
                const isActive = i === activeLayer;

                if (i > activeLayer && !completedLayers.includes(id)) return null;

                return (
                  <div key={id} className="fade-slide-in" style={{
                    background: "#111114", borderRadius: 12,
                    border: `1px solid ${isActive ? meta.color + "40" : "#1f1f24"}`,
                    overflow: "hidden",
                    transition: "border-color 0.3s",
                  }}>
                    <div style={{
                      padding: "14px 20px",
                      display: "flex", alignItems: "center", justifyContent: "space-between",
                      borderBottom: `1px solid ${meta.color}20`,
                      background: meta.color + "08",
                    }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{
                          width: 28, height: 28, borderRadius: "50%",
                          background: meta.color + "20", border: `2px solid ${meta.color}`,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 12, fontWeight: 800, color: meta.color,
                          fontFamily: "'DM Mono', monospace",
                        }}>
                          {i + 1}
                        </div>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 700, color: meta.color }}>{meta.label}</div>
                          <div style={{ fontSize: 10, color: "#4b5563" }}>{meta.description}</div>
                        </div>
                      </div>
                      {hasInsight && (
                        <ConfidenceRing
                          value={scenario.layers[id].confidence}
                          color={meta.color}
                          size={44}
                          delay={0}
                        />
                      )}
                    </div>

                    <div style={{ padding: "16px 20px" }}>
                      {thoughts.map((t, ti) => (
                        <div key={ti} className="fade-slide-in" style={{
                          display: "flex", gap: 10, alignItems: "flex-start",
                          marginBottom: 8, opacity: hasInsight ? 0.5 : 1,
                          transition: "opacity 0.5s",
                        }}>
                          <div style={{
                            width: 4, height: 4, borderRadius: "50%", marginTop: 8,
                            background: meta.color, flexShrink: 0,
                          }} />
                          <span style={{ fontSize: 12, color: "#9ca3af", lineHeight: 1.6, fontFamily: "'DM Mono', monospace" }}>
                            {t}
                          </span>
                        </div>
                      ))}

                      {isActive && !hasInsight && thoughts.length > 0 && thoughts.length < scenario.layers[id].thoughts.length && (
                        <div style={{ display: "flex", gap: 4, paddingLeft: 14, marginTop: 4 }}>
                          {[0, 1, 2].map(d => (
                            <div key={d} style={{
                              width: 5, height: 5, borderRadius: "50%", background: meta.color,
                              animation: `pulse 1.2s ease-in-out ${d * 0.2}s infinite`,
                            }} />
                          ))}
                        </div>
                      )}

                      {hasInsight && (
                        <div className="expand-in" style={{
                          marginTop: 12, padding: "14px 16px",
                          background: meta.color + "10",
                          borderRadius: 8, borderLeft: `3px solid ${meta.color}`,
                        }}>
                          <div style={{ fontSize: 10, color: meta.color, letterSpacing: 1.5, textTransform: "uppercase", marginBottom: 6, fontWeight: 700 }}>
                            Insight
                          </div>
                          <p style={{ fontSize: 14, color: "#e2e8f0", lineHeight: 1.8, margin: 0 }}>
                            <AnimatedText
                              text={scenario.layers[id].insight}
                              speed={18}
                              style={{ color: "#e2e8f0" }}
                            />
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {showSocratic && (
                <div className="fade-slide-in" style={{
                  background: "#111114", borderRadius: 12, border: "1px solid #ec489940",
                  padding: 24, marginTop: 4,
                }}>
                  <div style={{
                    display: "flex", alignItems: "center", gap: 10, marginBottom: 16,
                  }}>
                    <div style={{
                      width: 28, height: 28, borderRadius: "50%",
                      background: "#ec489920", border: "2px solid #ec4899",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: 14, color: "#ec4899",
                    }}>
                      ?
                    </div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#ec4899" }}>Socratic Inquiry</div>
                      <div style={{ fontSize: 10, color: "#4b5563" }}>Questions designed to deepen your understanding</div>
                    </div>
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {scenario.socraticQuestions.map((q, i) => (
                      <button
                        key={i}
                        className="fade-slide-in click-scale"
                        style={{
                          background: "#0a0a0c",
                          border: "1px solid #1f1f24",
                          borderRadius: 8,
                          padding: "14px 16px",
                          textAlign: "left",
                          cursor: "pointer",
                          color: "#d1d5db",
                          fontSize: 13,
                          lineHeight: 1.7,
                          fontFamily: "inherit",
                          animationDelay: `${i * 0.15}s`,
                          animationFillMode: "backwards",
                        }}
                        onClick={() => handleSocraticClick(q)}
                        onMouseEnter={(e) => {
                          e.currentTarget.style.borderColor = "#ec489960";
                          e.currentTarget.style.background = "#ec489908";
                          e.currentTarget.style.transform = "translateX(4px)";
                          e.currentTarget.style.boxShadow = "0 0 12px rgba(236,72,153,0.15)";
                        }}
                        onMouseLeave={(e) => {
                          e.currentTarget.style.borderColor = "#1f1f24";
                          e.currentTarget.style.background = "#0a0a0c";
                          e.currentTarget.style.transform = "translateX(0)";
                          e.currentTarget.style.boxShadow = "none";
                        }}
                      >
                        <span style={{ color: "#ec4899", marginRight: 8, fontWeight: 700 }}>{i + 1}.</span>
                        {q}
                      </button>
                    ))}
                  </div>

                  <div style={{
                    marginTop: 16, paddingTop: 16, borderTop: "1px solid #1f1f24",
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                  }}>
                    <span style={{ fontSize: 11, color: "#374151" }}>
                      Click a question to explore further, or ask something new
                    </span>
                    <button onClick={handleReset} className="click-scale" style={{
                      background: "#6366f1", border: "none", borderRadius: 6,
                      padding: "8px 16px", color: "#fff", fontSize: 12,
                      fontWeight: 700, cursor: "pointer",
                      fontFamily: "inherit",
                      boxShadow: "0 0 12px rgba(99,102,241,0.2)",
                    }}
                    onMouseEnter={(e) => e.currentTarget.style.transform = "scale(1.03)"}
                    onMouseLeave={(e) => e.currentTarget.style.transform = "scale(1)"}
                    >
                      New question
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
