import { Link } from 'react-router-dom';

const projects = [
  {
    id: 'architecture',
    path: '/architecture',
    title: 'E-Commerce Architecture Visualizer',
    description: 'Interactive layered system diagram with priority filtering, component deep-dives, and tradeoff analysis for a solo-team marketplace stack.',
    tags: ['Systems Design', 'Interactive', 'Architecture'],
    color: '#16a34a',
    accent: '#dcfce7',
  },
  {
    id: 'deep-dive',
    path: '/deep-dive',
    title: 'Technical Reference Deep Dive',
    description: 'Database schema explorer, checkout flow walkthrough with code references, scaling roadmap from $0 to $500k+ MRR, and a hands-on security checklist.',
    tags: ['Database Design', 'Security', 'Scaling'],
    color: '#6366f1',
    accent: '#e0e7ff',
  },
  {
    id: 'ai-workflow',
    path: '/ai-workflow',
    title: 'Narrative-Governed AI Workflow System',
    description: 'A user control framework for AI behavior and output quality. Input classification, behavioral sliders, and transparent confidence indicators.',
    tags: ['AI/UX', 'Interaction Design', 'Trust Calibration'],
    color: '#f59e0b',
    accent: '#fef3c7',
  },
  {
    id: 'thinking-partner',
    path: '/thinking-partner',
    title: 'Thinking Partner — Cognitive Architecture Demo',
    description: 'A system that won\'t tell you what you want to hear. Visible reasoning layers, Socratic follow-ups that find your blind spots, and the uncomfortable patience to hold tension without collapsing it into a clean answer.',
    tags: ['Cognitive Architecture', 'Socratic Inquiry', 'Blind Spot Detection'],
    color: '#6366f1',
    accent: '#e0e7ff',
  },
  {
    id: 'writing',
    path: '/writing',
    title: 'The Useful Villains Nobody Thanks',
    description: 'On the people who break your system to save it. An essay about workarounds, moral misclassification, and why divergence is a diagnostic signal.',
    tags: ['Systems Thinking', 'Essay', 'Design Culture'],
    color: '#ec4899',
    accent: '#fce7f3',
  },
];

export default function Home() {
  return (
    <div style={{ minHeight: '100vh' }}>
      <section style={{
        maxWidth: 800,
        margin: '0 auto',
        padding: '80px 24px 60px',
      }}>
        <div style={{
          fontSize: 11,
          color: '#4b5563',
          letterSpacing: 3,
          textTransform: 'uppercase',
          marginBottom: 16,
        }}>
          Portfolio
        </div>
        <h1 style={{
          fontSize: 'clamp(32px, 5vw, 48px)',
          fontWeight: 800,
          color: '#f9fafb',
          lineHeight: 1.1,
          letterSpacing: -1,
          marginBottom: 20,
        }}>
          Jennipher Troup
        </h1>
        <p style={{
          fontSize: 18,
          color: '#9ca3af',
          lineHeight: 1.7,
          maxWidth: 600,
          marginBottom: 12,
        }}>
          AI + UX Systems Designer
        </p>
        <p style={{
          fontSize: 15,
          color: '#6b7280',
          lineHeight: 1.8,
          maxWidth: 600,
          marginBottom: 48,
        }}>
          I design systems that help humans and intelligent tools make sense of complexity together.
          My work sits at the intersection of AI-enabled products, UX design, and sensemaking
          frameworks -- translating ambiguity, research, and data into usable structures
          that support trust, clarity, and action.
        </p>

        <div style={{
          fontSize: 10,
          color: '#4b5563',
          letterSpacing: 3,
          textTransform: 'uppercase',
          marginBottom: 20,
          paddingBottom: 12,
          borderBottom: '1px solid #1f1f24',
        }}>
          Selected Work
        </div>

        <div style={{ display: 'grid', gap: 16 }}>
          {projects.map((project) => (
            <Link
              key={project.id}
              to={project.path}
              className="card-interactive"
              style={{
                display: 'block',
                background: '#111114',
                border: '1px solid #1f1f24',
                borderRadius: 12,
                padding: '28px 28px 24px',
                cursor: 'pointer',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = project.color + '60';
                e.currentTarget.style.background = '#14141a';
                e.currentTarget.style.boxShadow = `0 0 20px ${project.color}15, 0 0 6px ${project.color}10`;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = '#1f1f24';
                e.currentTarget.style.background = '#111114';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: 10,
                marginBottom: 10,
              }}>
                <div style={{
                  width: 8,
                  height: 8,
                  borderRadius: '50%',
                  background: project.color,
                  flexShrink: 0,
                }} />
                <h2 style={{
                  fontSize: 17,
                  fontWeight: 700,
                  color: '#f1f5f9',
                  letterSpacing: -0.3,
                }}>
                  {project.title}
                </h2>
              </div>
              <p style={{
                fontSize: 13,
                color: '#9ca3af',
                lineHeight: 1.7,
                marginBottom: 14,
                paddingLeft: 18,
              }}>
                {project.description}
              </p>
              <div style={{
                display: 'flex',
                gap: 6,
                flexWrap: 'wrap',
                paddingLeft: 18,
              }}>
                {project.tags.map((tag) => (
                  <span key={tag} style={{
                    fontSize: 10,
                    padding: '3px 10px',
                    borderRadius: 20,
                    background: project.color + '15',
                    color: project.color,
                    fontWeight: 600,
                    letterSpacing: 0.3,
                  }}>
                    {tag}
                  </span>
                ))}
              </div>
            </Link>
          ))}
        </div>
      </section>

      <footer style={{
        borderTop: '1px solid #1f1f24',
        padding: '24px',
        textAlign: 'center',
      }}>
        <p style={{ fontSize: 12, color: '#4b5563', marginBottom: 8 }}>
          AI + UX Systems Design | Narrative-Driven Product & Decision Frameworks
        </p>
        <p style={{ fontSize: 11, color: '#374151' }}>
          Jennipher Troup
        </p>
      </footer>
    </div>
  );
}
