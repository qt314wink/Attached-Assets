import { useState } from "react";

const queryTypes = [
  { id: "exploratory", label: "Exploratory Question", description: "Open-ended inquiry seeking multiple perspectives. AI should offer options, not single answers.", color: "#6366f1" },
  { id: "decision", label: "Decision Support", description: "Analysis needed for a specific choice. AI should surface tradeoffs and failure modes.", color: "#10b981" },
  { id: "creative", label: "Creative Generation", description: "Request for novel content. AI should prioritize variety and originality over accuracy.", color: "#f59e0b" },
  { id: "factual", label: "Factual Lookup", description: "Query requiring verified information. AI should cite sources and flag uncertainty.", color: "#ec4899" },
];

const defaultSliders = {
  formality: 65,
  depth: 50,
  tone: 40,
  confidence: 70,
};

const sliderConfig = [
  { id: "formality", label: "Formality Level", low: "Casual", high: "Technical", color: "#6366f1" },
  { id: "depth", label: "Response Depth", low: "Brief", high: "Comprehensive", color: "#0ea5e9" },
  { id: "tone", label: "Tone", low: "Professional", high: "Empathetic", color: "#10b981" },
  { id: "confidence", label: "Confidence Display", low: "Implicit", high: "Explicit", color: "#f59e0b" },
];

const sampleOutputs = {
  exploratory: {
    title: "What are the most promising approaches to reducing urban heat islands?",
    content: [
      { text: "Urban heat islands result from concentrated infrastructure absorbing and re-emitting solar energy. There are several distinct approaches, each with different tradeoff profiles:", confidence: "high", type: "context" },
      { text: "1. Green infrastructure (tree canopy, green roofs) -- most studied, 2-8\u00b0C surface reduction documented. Cost: moderate. Timeline: 5-15 years for canopy maturity.", confidence: "high", type: "finding" },
      { text: "2. Cool/reflective surfaces (high-albedo roofing, cool pavements) -- faster deployment, 1-3\u00b0C reduction. Trade-off: can increase heating costs in winter.", confidence: "high", type: "finding" },
      { text: "3. Urban geometry redesign (ventilation corridors, building orientation) -- highest potential impact but requires long-term planning integration. Limited implementation data.", confidence: "medium", type: "finding" },
      { text: "4. Water-based cooling (misting systems, urban water features) -- effective but resource-intensive. Viability depends heavily on local water availability.", confidence: "medium", type: "finding" },
      { text: "Emerging: bio-inspired materials that mimic desert beetle shell structures for passive cooling. Lab-stage only; no field deployment data yet.", confidence: "low", type: "speculative" },
    ],
    scores: { relevance: 92, clarity: 88, completeness: 85, sources: 6, assumptions: 1, needsVerification: 1 },
  },
  decision: {
    title: "Should we migrate from REST to GraphQL for our product API?",
    content: [
      { text: "This decision hinges on three factors: team size, client diversity, and query complexity. Here's the tradeoff analysis:", confidence: "high", type: "context" },
      { text: "FOR GraphQL: Eliminates over-fetching (measured 40-60% payload reduction in comparable migrations). Single endpoint simplifies client code. Strong typing catches errors at build time.", confidence: "high", type: "finding" },
      { text: "AGAINST GraphQL: Adds complexity to caching (no native HTTP caching). Requires schema governance discipline. N+1 query problems shift from client to server. Learning curve for team.", confidence: "high", type: "finding" },
      { text: "HIDDEN ASSUMPTION: This comparison assumes your REST API has significant over-fetching problems. If your current endpoints are already well-tailored, the migration cost may exceed the benefit.", confidence: "medium", type: "assumption" },
      { text: "FAILURE MODE: Teams that migrate without establishing schema review processes often end up with a GraphQL API that's harder to maintain than the REST one it replaced.", confidence: "medium", type: "warning" },
      { text: "Recommendation: For teams under 5 engineers with fewer than 3 distinct clients, tRPC offers most of GraphQL's benefits with significantly less operational overhead.", confidence: "medium", type: "finding" },
    ],
    scores: { relevance: 95, clarity: 91, completeness: 88, sources: 4, assumptions: 2, needsVerification: 2 },
  },
  creative: {
    title: "Generate tagline concepts for a sustainable packaging startup",
    content: [
      { text: "Five distinct concepts, each targeting a different emotional register:", confidence: null, type: "context" },
      { text: "1. \"Packaging that packages itself out of a job.\" -- Self-aware, clever. Appeals to tech-forward buyers who appreciate systems thinking.", confidence: null, type: "creative" },
      { text: "2. \"What you throw away says everything.\" -- Provocative, guilt-adjacent without being preachy. Works for premium positioning.", confidence: null, type: "creative" },
      { text: "3. \"Built to disappear.\" -- Minimal, confident. Strong for B2B where buyers value directness over emotion.", confidence: null, type: "creative" },
      { text: "4. \"The last box you'll feel bad about.\" -- Conversational, warm. Good for DTC brands targeting conscious consumers.", confidence: null, type: "creative" },
      { text: "5. \"Earth called. We answered.\" -- Bold, slightly irreverent. Risks cliche but has high memorability potential.", confidence: null, type: "creative" },
    ],
    scores: { relevance: 85, clarity: 94, completeness: 80, sources: 0, assumptions: 0, needsVerification: 0 },
  },
  factual: {
    title: "What is the current global adoption rate of electric vehicles?",
    content: [
      { text: "Global EV sales reached approximately 14 million units in 2024, representing roughly 18% of total new car sales worldwide. This represents a 25% year-over-year increase.", confidence: "high", type: "finding" },
      { text: "Regional breakdown: China leads at ~45% of new sales being electric, followed by Northern Europe (35-50% depending on country), and the US at approximately 9%.", confidence: "high", type: "finding" },
      { text: "The global EV fleet (total vehicles on road) is approximately 40 million, or about 3% of the total passenger vehicle fleet of ~1.4 billion.", confidence: "high", type: "finding" },
      { text: "NOTE: These figures include both BEV (battery electric) and PHEV (plug-in hybrid). BEV-only figures are approximately 30% lower. Definition matters for your use case.", confidence: "high", type: "assumption" },
      { text: "VERIFICATION NEEDED: 2025 projections vary significantly between sources (IEA, BloombergNEF, S&P Global). The range spans 16-22% market share depending on methodology and China subsidy policy changes.", confidence: "medium", type: "warning" },
    ],
    scores: { relevance: 96, clarity: 92, completeness: 82, sources: 8, assumptions: 1, needsVerification: 2 },
  },
};

function ConfidenceBadge({ level }) {
  if (!level) return null;
  const config = {
    high: { bg: "#052e16", border: "#166534", color: "#4ade80", label: "Well-supported" },
    medium: { bg: "#1c1007", border: "#78350f", color: "#fbbf24", label: "Moderate confidence" },
    low: { bg: "#1f0707", border: "#7f1d1d", color: "#f87171", label: "Low confidence" },
  };
  const c = config[level];
  return (
    <span style={{
      fontSize: 9, padding: "2px 8px", borderRadius: 4,
      background: c.bg, border: `1px solid ${c.border}`, color: c.color,
      fontWeight: 700, letterSpacing: 0.5, whiteSpace: "nowrap",
    }}>
      {c.label}
    </span>
  );
}

function TypeBadge({ type }) {
  const config = {
    context: { color: "#6b7280" },
    finding: { color: "#60a5fa" },
    assumption: { color: "#fbbf24" },
    warning: { color: "#f87171" },
    speculative: { color: "#c084fc" },
    creative: { color: "#34d399" },
  };
  const c = config[type] || config.context;
  return (
    <span style={{
      fontSize: 9, color: c.color, letterSpacing: 1,
      textTransform: "uppercase", fontWeight: 600,
    }}>
      {type}
    </span>
  );
}

export default function AIWorkflow() {
  const [selectedType, setSelectedType] = useState("exploratory");
  const [sliders, setSliders] = useState(defaultSliders);

  const updateSlider = (id, value) => {
    setSliders(prev => ({ ...prev, [id]: parseInt(value) }));
  };

  const output = sampleOutputs[selectedType];

  const formalityLabel = sliders.formality > 60 ? "Technical" : sliders.formality > 30 ? "Balanced" : "Casual";
  const depthLabel = sliders.depth > 60 ? "Comprehensive" : sliders.depth > 30 ? "Standard" : "Brief";

  return (
    <div style={{
      background: "#0f0f11",
      minHeight: "100vh",
      padding: "32px 24px",
      color: "#e2e8f0",
    }}>
      <div style={{ maxWidth: 960, margin: "0 auto" }}>
        <div style={{ marginBottom: 32 }}>
          <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 3, textTransform: "uppercase", marginBottom: 6 }}>
            Interactive Prototype
          </div>
          <h1 style={{ fontSize: 24, fontWeight: 800, color: "#f9fafb", margin: "0 0 6px", letterSpacing: -0.5 }}>
            Narrative-Governed AI Workflow System
          </h1>
          <p style={{ fontSize: 13, color: "#9ca3af", margin: 0, maxWidth: 640, lineHeight: 1.7 }}>
            A user control framework for AI behavior and output quality. Classify your intent, adjust behavioral parameters, and see transparent confidence indicators in every response.
          </p>
        </div>

        <div className="responsive-sidebar" style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: 20, alignItems: "flex-start" }}>
          <div className="responsive-sidebar-panel" style={{ position: "sticky", top: 80 }}>
            <div style={{ background: "#111114", borderRadius: 12, border: "1px solid #1f1f24", padding: 20, marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 2, textTransform: "uppercase", marginBottom: 14, fontWeight: 700 }}>
                Layer 1: Input Classification
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                {queryTypes.map((qt) => (
                  <button
                    key={qt.id}
                    className="click-scale"
                    onClick={() => setSelectedType(qt.id)}
                    style={{
                      padding: "10px 14px",
                      borderRadius: 8,
                      border: `1px solid ${selectedType === qt.id ? qt.color : "#2d2d35"}`,
                      background: selectedType === qt.id ? qt.color + "18" : "#0f0f11",
                      cursor: "pointer",
                      textAlign: "left",
                      transition: "all 0.15s",
                      boxShadow: selectedType === qt.id ? `0 0 10px ${qt.color}20` : "none",
                    }}
                  >
                    <div style={{ fontSize: 12, fontWeight: 700, color: selectedType === qt.id ? qt.color : "#9ca3af", marginBottom: 2 }}>
                      {qt.label}
                    </div>
                    <div style={{ fontSize: 10, color: "#4b5563", lineHeight: 1.5 }}>
                      {qt.description}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div style={{ background: "#111114", borderRadius: 12, border: "1px solid #1f1f24", padding: 20 }}>
              <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 2, textTransform: "uppercase", marginBottom: 14, fontWeight: 700 }}>
                Layer 2: Behavioral Controls
              </div>
              {sliderConfig.map((s) => (
                <div key={s.id} style={{ marginBottom: 18 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                    <span style={{ fontSize: 11, color: "#9ca3af", fontWeight: 600 }}>{s.label}</span>
                    <span style={{ fontSize: 11, color: s.color, fontWeight: 700, fontFamily: "'DM Mono', monospace" }}>{sliders[s.id]}</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={sliders[s.id]}
                    className="click-scale"
                    onChange={(e) => updateSlider(s.id, e.target.value)}
                    style={{
                      width: "100%",
                      height: 4,
                      appearance: "none",
                      background: `linear-gradient(to right, ${s.color} ${sliders[s.id]}%, #2d2d35 ${sliders[s.id]}%)`,
                      borderRadius: 2,
                      outline: "none",
                      cursor: "pointer",
                    }}
                  />
                  <div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}>
                    <span style={{ fontSize: 9, color: "#374151" }}>{s.low}</span>
                    <span style={{ fontSize: 9, color: "#374151" }}>{s.high}</span>
                  </div>
                </div>
              ))}

              <div style={{ borderTop: "1px solid #1f1f24", paddingTop: 14, marginTop: 8 }}>
                <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 1, marginBottom: 8 }}>ACTIVE PRESET</div>
                <div style={{ fontSize: 11, color: "#9ca3af" }}>
                  {formalityLabel} / {depthLabel} / Confidence {sliders.confidence > 50 ? "Visible" : "Subtle"}
                </div>
              </div>
            </div>
          </div>

          <div>
            <div style={{ background: "#111114", borderRadius: 12, border: "1px solid #1f1f24", padding: 24, marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 2, textTransform: "uppercase", marginBottom: 6, fontWeight: 700 }}>
                Sample Query
              </div>
              <div style={{ fontSize: 15, color: "#f1f5f9", fontWeight: 600, lineHeight: 1.5, marginBottom: 8 }}>
                {output.title}
              </div>
              <div style={{ display: "flex", gap: 6 }}>
                <span style={{
                  fontSize: 10, padding: "2px 8px", borderRadius: 4,
                  background: queryTypes.find(q => q.id === selectedType).color + "20",
                  color: queryTypes.find(q => q.id === selectedType).color,
                  fontWeight: 700, letterSpacing: 0.5,
                }}>
                  {queryTypes.find(q => q.id === selectedType).label}
                </span>
              </div>
            </div>

            <div style={{ background: "#111114", borderRadius: 12, border: "1px solid #1f1f24", padding: 24, marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 2, textTransform: "uppercase", marginBottom: 16, fontWeight: 700 }}>
                AI Response
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                {output.content.map((item, i) => (
                  <div key={i} style={{
                    padding: "12px 16px",
                    background: item.type === "warning" ? "#1c100720" : item.type === "assumption" ? "#1c100710" : "#0a0a0c",
                    borderRadius: 8,
                    border: `1px solid ${item.type === "warning" ? "#92400e40" : item.type === "assumption" ? "#78350f30" : "#1f1f24"}`,
                  }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6, gap: 8 }}>
                      <TypeBadge type={item.type} />
                      {sliders.confidence > 30 && <ConfidenceBadge level={item.confidence} />}
                    </div>
                    <p style={{
                      fontSize: sliders.formality > 60 ? 13 : 14,
                      color: "#d1d5db",
                      lineHeight: 1.7,
                      margin: 0,
                    }}>
                      {item.text}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div style={{ background: "#111114", borderRadius: 12, border: "1px solid #1f1f24", padding: 24 }}>
              <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 2, textTransform: "uppercase", marginBottom: 16, fontWeight: 700 }}>
                Layer 3: Output Quality Dashboard
              </div>
              <div className="responsive-grid-3" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10, marginBottom: 16 }}>
                {[
                  { label: "Relevance", value: output.scores.relevance, color: output.scores.relevance > 90 ? "#10b981" : "#f59e0b" },
                  { label: "Clarity", value: output.scores.clarity, color: output.scores.clarity > 90 ? "#10b981" : "#f59e0b" },
                  { label: "Completeness", value: output.scores.completeness, color: output.scores.completeness > 85 ? "#10b981" : "#f59e0b" },
                ].map((metric) => (
                  <div key={metric.label} style={{ background: "#0a0a0c", borderRadius: 8, padding: "14px 16px", border: "1px solid #1f1f24" }}>
                    <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 1, textTransform: "uppercase", marginBottom: 8 }}>{metric.label}</div>
                    <div style={{ fontSize: 24, fontWeight: 800, color: metric.color, fontFamily: "'DM Mono', monospace" }}>{metric.value}</div>
                    <div style={{ marginTop: 6, height: 3, background: "#1f1f24", borderRadius: 2, overflow: "hidden" }}>
                      <div style={{ width: `${metric.value}%`, height: "100%", background: metric.color, borderRadius: 2 }} />
                    </div>
                  </div>
                ))}
              </div>

              <div className="responsive-grid-3" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
                <div style={{ background: "#0a0a0c", borderRadius: 8, padding: "12px 16px", border: "1px solid #1f1f24", textAlign: "center" }}>
                  <div style={{ fontSize: 20, fontWeight: 800, color: "#60a5fa", fontFamily: "'DM Mono', monospace" }}>{output.scores.sources}</div>
                  <div style={{ fontSize: 10, color: "#4b5563", marginTop: 4 }}>Sources Used</div>
                </div>
                <div style={{ background: "#0a0a0c", borderRadius: 8, padding: "12px 16px", border: "1px solid #1f1f24", textAlign: "center" }}>
                  <div style={{ fontSize: 20, fontWeight: 800, color: "#fbbf24", fontFamily: "'DM Mono', monospace" }}>{output.scores.assumptions}</div>
                  <div style={{ fontSize: 10, color: "#4b5563", marginTop: 4 }}>Assumptions Flagged</div>
                </div>
                <div style={{ background: "#0a0a0c", borderRadius: 8, padding: "12px 16px", border: "1px solid #1f1f24", textAlign: "center" }}>
                  <div style={{ fontSize: 20, fontWeight: 800, color: "#f87171", fontFamily: "'DM Mono', monospace" }}>{output.scores.needsVerification}</div>
                  <div style={{ fontSize: 10, color: "#4b5563", marginTop: 4 }}>Needs Verification</div>
                </div>
              </div>
            </div>

            <div style={{
              marginTop: 24,
              background: "#111114",
              borderRadius: 12,
              border: "1px solid #1f1f24",
              padding: 24,
            }}>
              <div style={{ fontSize: 10, color: "#4b5563", letterSpacing: 2, textTransform: "uppercase", marginBottom: 14, fontWeight: 700 }}>
                Design Rationale
              </div>
              <div style={{ display: "grid", gap: 16 }}>
                <div>
                  <h4 style={{ fontSize: 13, fontWeight: 700, color: "#e2e8f0", marginBottom: 6 }}>Why User Control Matters</h4>
                  <p style={{ fontSize: 12, color: "#6b7280", lineHeight: 1.7 }}>
                    Research consistently shows that perceived control increases both satisfaction and appropriate reliance on automated systems (Parasuraman & Riley, 1997). This system introduces granular, meaningful control parameters that reduce cognitive load, enable learning, and build trust.
                  </p>
                </div>
                <div>
                  <h4 style={{ fontSize: 13, fontWeight: 700, color: "#e2e8f0", marginBottom: 6 }}>Why Transparency Indicators Matter</h4>
                  <p style={{ fontSize: 12, color: "#6b7280", lineHeight: 1.7 }}>
                    The output quality dashboard addresses the "confidence calibration" problem. When systems provide uniform-confidence outputs regardless of actual certainty, users either over-rely, under-rely, or verify everything -- negating efficiency benefits entirely (Lee & See, 2004).
                  </p>
                </div>
                <div>
                  <h4 style={{ fontSize: 13, fontWeight: 700, color: "#e2e8f0", marginBottom: 6 }}>Why Input Classification Matters</h4>
                  <p style={{ fontSize: 12, color: "#6b7280", lineHeight: 1.7 }}>
                    Different query types require fundamentally different response strategies. Without explicit classification, AI systems must guess intent -- often incorrectly. Making intent explicit creates shared understanding and reduces interaction friction.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
