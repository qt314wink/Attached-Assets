import { Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import ArchitectureVisualizer from './pages/ArchitectureVisualizer';
import DeepDive from './pages/DeepDive';
import AIWorkflow from './pages/AIWorkflow';
import Writing from './pages/Writing';
import ThinkingPartner from './pages/ThinkingPartner';

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/architecture" element={<ArchitectureVisualizer />} />
        <Route path="/deep-dive" element={<DeepDive />} />
        <Route path="/ai-workflow" element={<AIWorkflow />} />
        <Route path="/thinking-partner" element={<ThinkingPartner />} />
        <Route path="/writing" element={<Writing />} />
      </Route>
    </Routes>
  );
}
