import { Outlet, NavLink, useLocation } from 'react-router-dom';
import { useState, useEffect } from 'react';

const navItems = [
  { path: '/', label: 'Home' },
  { path: '/architecture', label: 'Architecture' },
  { path: '/deep-dive', label: 'Deep Dive' },
  { path: '/ai-workflow', label: 'AI Workflow' },
  { path: '/thinking-partner', label: 'Thinking Partner' },
  { path: '/writing', label: 'Writing' },
];

export default function Layout() {
  const location = useLocation();
  const isHome = location.pathname === '/';
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const mql = window.matchMedia('(max-width: 768px)');
    setIsMobile(mql.matches);
    const handler = (e) => setIsMobile(e.matches);
    mql.addEventListener('change', handler);
    return () => mql.removeEventListener('change', handler);
  }, []);

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <nav style={{
        position: 'sticky',
        top: 0,
        zIndex: 100,
        background: 'rgba(10, 10, 12, 0.85)',
        backdropFilter: 'blur(16px)',
        borderBottom: '1px solid #1f1f24',
        padding: '0 24px',
      }}>
        <div style={{
          maxWidth: 1100,
          margin: '0 auto',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          height: 56,
        }}>
          <NavLink to="/" style={{
            fontSize: 14,
            fontWeight: 700,
            color: '#f9fafb',
            letterSpacing: -0.3,
            fontFamily: "'DM Mono', monospace",
          }}>
            JT
          </NavLink>

          <div className="nav-scroll" style={{ display: 'flex', gap: 4 }}>
            {navItems.map((item) => (
              <NavLink
                key={item.path}
                to={item.path}
                className="click-scale"
                style={({ isActive }) => ({
                  padding: isMobile ? '6px 10px' : '6px 14px',
                  borderRadius: 6,
                  fontSize: isMobile ? 11 : 12,
                  fontWeight: isActive ? 600 : 400,
                  color: isActive ? '#f9fafb' : '#6b7280',
                  background: isActive ? '#1e1e26' : 'transparent',
                  boxShadow: isActive ? '0 0 8px rgba(99,102,241,0.15)' : 'none',
                  transition: 'all 0.15s',
                  letterSpacing: 0.2,
                  whiteSpace: 'nowrap',
                })}
              >
                {item.label}
              </NavLink>
            ))}
          </div>
        </div>
      </nav>

      <main style={{ flex: 1 }}>
        <Outlet />
      </main>

      {!isHome && (
        <footer style={{
          borderTop: '1px solid #1f1f24',
          padding: '20px 24px',
          textAlign: 'center',
          fontSize: 11,
          color: '#374151',
          letterSpacing: 0.5,
        }}>
          Jennipher Troup - AI + UX Systems Design
        </footer>
      )}
    </div>
  );
}
